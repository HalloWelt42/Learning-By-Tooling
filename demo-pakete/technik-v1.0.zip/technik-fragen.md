# Technik-Grundlagen -- FRAGEN
# 20 Karten zu IT, Netzwerke, Betriebssysteme, Sicherheit

---

```
K-001 | Grundlagen
Was ist eine IP-Adresse und wozu dient sie?
```

---

```
K-002 | Grundlagen
Was ist der Unterschied zwischen RAM und Festplatte?
```

---

```
K-003 | Grundlagen
Was bedeutet "Open Source" und nenne drei Beispiele.
```

---

```
K-004 | Theorie
Wie funktioniert das DNS (Domain Name System)?
```

---

```
K-005 | Theorie
Was ist der Unterschied zwischen TCP und UDP?
```

---

```
K-006 | Theorie
Was ist Verschlüsselung und worin unterscheiden sich symmetrische und asymmetrische Verschlüsselung?
```

---

```
K-007 | Praxis
Wie findest du unter Linux heraus welche Prozesse gerade laufen?
```

---

```
K-008 | Praxis
Wie erstellst du einen SSH-Schlüssel und wozu braucht man ihn?
```

---

```
K-009 | Verfahren
Erkläre den Ablauf eines HTTPS-Verbindungsaufbaus (TLS-Handshake) in einfachen Worten.
```

---

```
K-010 | Verfahren
Was passiert wenn du eine URL in den Browser eingibst? Beschreibe die Schritte.
```

---

```
K-011 | Grundlagen
Was ist ein Container (z.B. Docker) und worin unterscheidet er sich von einer virtuellen Maschine?
```

---

```
K-012 | Grundlagen
Was ist ein Port und warum hat HTTP den Port 80?
```

---

```
K-013 | Theorie
Was ist RAID und welche RAID-Level gibt es?
```

---

```
K-014 | Theorie
Was ist der Unterschied zwischen IPv4 und IPv6?
```

---

```
K-015 | Praxis
Wie richtest du eine Firewall-Regel unter Linux ein?
```

---

```
K-016 | Praxis
Wie prüfst du ob ein Server erreichbar ist und auf welchem Port er lauscht?
```

---

```
K-017 | Vertiefung
Was ist ein Reverse Proxy und wann setzt man ihn ein?
```

---

```
K-018 | Vertiefung
Was ist CI/CD und warum ist es wichtig?
```

---

```
K-019 | Pruefung
Nenne fünf wichtige Linux-Befehle und beschreibe kurz was sie tun.
```

---

```
K-020 | Pruefung
Was sind die drei Säulen der IT-Sicherheit?
```
