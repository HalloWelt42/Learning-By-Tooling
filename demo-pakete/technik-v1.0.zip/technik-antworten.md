# Technik-Grundlagen -- ANTWORTEN

---

```
A-001 | Grundlagen -> K-001
Eine IP-Adresse ist die eindeutige Nummer eines Geräts im Netzwerk.
Sie funktioniert wie eine Postadresse: Datenpakete wissen
wohin sie geschickt werden müssen.

IPv4-Beispiel: 192.168.1.100 (4 Zahlen von 0-255)
IPv6-Beispiel: 2001:0db8:85a3::8a2e:0370:7334

Jedes Gerät im Internet braucht eine öffentliche IP-Adresse.
Im lokalen Netz werden private Adressen (192.168.x.x) verwendet.
```

---

```
A-002 | Grundlagen -> K-002
RAM (Arbeitsspeicher):
Schnell, flüchtig (Daten weg bei Stromausfall),
begrenzt (8-64 GB typisch). Hier laufen aktive Programme.

Festplatte (SSD/HDD):
Langsamer, dauerhaft (Daten bleiben ohne Strom),
groß (256 GB bis mehrere TB). Hier liegen Dateien und das Betriebssystem.

Analogie: RAM ist der Schreibtisch (Arbeitsfläche),
Festplatte ist der Aktenschrank (Langzeitlager).
```

---

```
A-003 | Grundlagen -> K-003
Open Source bedeutet: Der Quellcode einer Software ist
öffentlich einsehbar, nutzbar und veränderbar.

Jeder kann den Code lesen, verbessern und weiterverbreiten.
Die genauen Regeln legt die jeweilige Lizenz fest (MIT, GPL, Apache).

Beispiele:
Linux (Betriebssystem)
Firefox (Browser)
LibreOffice (Bürosoftware)
PostgreSQL (Datenbank)
```

---

```
A-004 | Theorie -> K-004
DNS übersetzt lesbare Domainnamen in IP-Adressen.

Ablauf wenn du "google.de" eingibst:
1. Browser fragt den lokalen DNS-Cache
2. Falls nicht gefunden: Anfrage an den DNS-Resolver deines Providers
3. Resolver fragt Root-Server -> .de-Server -> google.de-Server
4. Ergebnis: IP-Adresse (z.B. 142.250.185.99)
5. Browser verbindet sich mit dieser IP

Ohne DNS müsstest du dir IP-Adressen merken statt Namen.
```

---

```
A-005 | Theorie -> K-005
TCP (Transmission Control Protocol):
Verbindungsorientiert. Stellt sicher dass alle Pakete
ankommen und in der richtigen Reihenfolge sind.
Langsamer aber zuverlässig. Für: Web, E-Mail, Dateiübertragung.

UDP (User Datagram Protocol):
Verbindungslos. Pakete werden gesendet ohne Bestätigung.
Schneller aber unzuverlässig. Für: Video-Streaming, Gaming, DNS.

TCP = Einschreiben, UDP = Postkarte.
```

---

```
A-006 | Theorie -> K-006
Verschlüsselung wandelt lesbare Daten in unlesbaren Code um.
Nur wer den Schlüssel hat kann sie wieder lesen.

Symmetrisch: Ein Schlüssel für Ver- und Entschlüsselung.
Schnell aber Problem: Wie tauscht man den Schlüssel sicher aus?
Beispiel: AES.

Asymmetrisch: Zwei Schlüssel (öffentlich + privat).
Öffentlicher Schlüssel verschlüsselt, nur der private entschlüsselt.
Langsamer aber sicherer Schlüsselaustausch. Beispiel: RSA.

In der Praxis werden beide kombiniert (TLS/HTTPS).
```

---

```
A-007 | Praxis -> K-007
Wichtigste Befehle:

ps aux           -- Alle laufenden Prozesse anzeigen
top              -- Live-Ansicht mit CPU/RAM-Verbrauch
htop             -- Komfortablere Version von top
ps aux | grep X  -- Bestimmten Prozess suchen
kill PID         -- Prozess beenden (PID = Prozess-ID)
```

---

```
A-008 | Praxis -> K-008
SSH-Schlüssel erzeugen:
ssh-keygen -t ed25519

Das erstellt zwei Dateien:
~/.ssh/id_ed25519       (privater Schlüssel, GEHEIM)
~/.ssh/id_ed25519.pub   (öffentlicher Schlüssel, darf geteilt werden)

Wozu: Passwortloses Anmelden an Servern.
Den öffentlichen Schlüssel auf dem Server in
~/.ssh/authorized_keys eintragen.
```

---

```
A-009 | Verfahren -> K-009
1. Client sagt "Hallo" und schickt unterstützte Verschlüsselungen
2. Server antwortet mit gewählter Verschlüsselung + Zertifikat
3. Client prüft das Zertifikat (ist der Server echt?)
4. Beide einigen sich auf einen gemeinsamen Sitzungsschlüssel
5. Ab jetzt ist alles verschlüsselt

Das Zertifikat wird von einer Zertifizierungsstelle (CA) ausgestellt.
Der Browser vertraut bestimmten CAs (Vertrauenskette).
```

---

```
A-010 | Verfahren -> K-010
1. Browser parst die URL (Protokoll, Domain, Pfad)
2. DNS-Auflösung: Domain -> IP-Adresse
3. TCP-Verbindung zum Server aufbauen (Port 443 für HTTPS)
4. TLS-Handshake (Verschlüsselung aushandeln)
5. HTTP-Request senden (GET /pfad)
6. Server verarbeitet die Anfrage
7. Server schickt HTTP-Response (HTML, CSS, JS)
8. Browser parst HTML, lädt CSS/JS/Bilder nach
9. Browser rendert die Seite
```

---

```
A-011 | Grundlagen -> K-011
Container: Isolierte Umgebung die sich den Betriebssystem-Kernel
mit dem Host teilt. Leichtgewichtig (MB statt GB), startet in Sekunden.
Enthält nur die App + Abhängigkeiten.

VM: Komplettes Betriebssystem mit eigenem Kernel auf simulierter Hardware.
Schwerer (GB), startet in Minuten. Stärkere Isolation.

Container = Wohnung im Mehrfamilienhaus (geteilte Infrastruktur).
VM = Eigenständiges Haus (alles eigens).
```

---

```
A-012 | Grundlagen -> K-012
Ein Port ist eine logische Nummer (0-65535) die einen
bestimmten Dienst auf einem Server identifiziert.

Eine IP-Adresse ist die Hausnummer, der Port ist die Wohnungsnummer.

Standard-Ports:
80 = HTTP (unverschlüsseltes Web)
443 = HTTPS (verschlüsseltes Web)
22 = SSH (sichere Fernverbindung)
25 = SMTP (E-Mail-Versand)
```

---

```
A-013 | Theorie -> K-013
RAID (Redundant Array of Independent Disks) kombiniert
mehrere Festplatten zu einem logischen Verbund.

RAID 0: Striping. Daten auf beide Platten verteilt. Schneller,
aber kein Schutz (eine Platte kaputt = alles weg).

RAID 1: Spiegelung. Gleiche Daten auf beiden Platten.
Schutz bei Ausfall einer Platte, halbe Kapazität.

RAID 5: Striping + Parität. Mindestens 3 Platten.
Eine darf ausfallen, Daten bleiben erhalten.

RAID 10: Kombination aus 1 und 0. Schnell und sicher,
braucht mindestens 4 Platten.
```

---

```
A-014 | Theorie -> K-014
IPv4: 32 Bit, ca. 4,3 Milliarden Adressen.
Format: 192.168.1.1 (vier Dezimalzahlen)
Problem: Adressen sind fast aufgebraucht.

IPv6: 128 Bit, praktisch unbegrenzt (340 Sextillionen).
Format: 2001:db8:85a3::8a2e:370:7334 (Hexadezimal)
Löst das Knappheitsproblem und hat eingebaute Sicherheit (IPsec).
```

---

```
A-015 | Praxis -> K-015
Mit iptables (klassisch) oder ufw (einfacher):

ufw (Uncomplicated Firewall):
sudo ufw enable                    -- Firewall einschalten
sudo ufw allow 22/tcp              -- SSH erlauben
sudo ufw allow 80,443/tcp          -- Web erlauben
sudo ufw deny 3306                 -- MySQL blockieren
sudo ufw status                    -- Regeln anzeigen

iptables:
sudo iptables -A INPUT -p tcp --dport 22 -j ACCEPT
```

---

```
A-016 | Praxis -> K-016
Erreichbarkeit prüfen:
ping server.de           -- Antwortet der Server?
traceroute server.de     -- Welchen Weg nehmen die Pakete?

Port prüfen:
nc -zv server.de 80      -- Ist Port 80 offen?
nmap server.de           -- Welche Ports sind offen?
ss -tlnp                 -- Auf dem Server: welche Ports lauschen?
curl -v http://server.de -- HTTP-Verbindung testen
```

---

```
A-017 | Vertiefung -> K-017
Ein Reverse Proxy sitzt zwischen Client und Backend-Server.
Er nimmt Anfragen entgegen und leitet sie weiter.

Einsatzgebiete:
SSL-Terminierung (HTTPS entschlüsseln, intern HTTP weiterleiten)
Load Balancing (Anfragen auf mehrere Server verteilen)
Caching (häufige Antworten zwischenspeichern)
Schutz (Backend-Server sind nicht direkt erreichbar)

Beispiele: nginx, Caddy, Traefik, HAProxy.
```

---

```
A-018 | Vertiefung -> K-018
CI/CD = Continuous Integration / Continuous Delivery (oder Deployment).

CI: Code-Änderungen werden automatisch gebaut und getestet.
Bei jedem Commit läuft die Pipeline: Compile, Tests, Lint.
Fehler werden sofort erkannt statt erst beim Release.

CD (Delivery): Getesteter Code wird automatisch in eine
Staging-Umgebung bereitgestellt.
CD (Deployment): Automatisch bis in die Produktion.

Werkzeuge: GitHub Actions, GitLab CI, Jenkins.
```

---

```
A-019 | Pruefung -> K-019
1. ls     -- Verzeichnisinhalt auflisten
2. cd     -- Verzeichnis wechseln
3. grep   -- Text in Dateien suchen
4. chmod  -- Dateiberechtigungen ändern
5. ssh    -- Sichere Verbindung zu einem entfernten Rechner

Weitere wichtige:
cat (Datei anzeigen), cp (kopieren), mv (verschieben),
rm (löschen), sudo (als Admin ausführen).
```

---

```
A-020 | Pruefung -> K-020
Die drei Säulen der IT-Sicherheit (CIA-Triade):

1. Vertraulichkeit (Confidentiality):
Nur Berechtigte haben Zugriff. Mittel: Verschlüsselung, Zugriffsrechte.

2. Integrität (Integrity):
Daten sind korrekt und unverändert. Mittel: Prüfsummen, digitale Signaturen.

3. Verfügbarkeit (Availability):
Systeme sind erreichbar wenn sie gebraucht werden.
Mittel: Redundanz, Backups, Monitoring.
```
