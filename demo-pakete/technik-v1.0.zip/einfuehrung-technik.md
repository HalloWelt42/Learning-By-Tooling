# Technik-Grundlagen -- Begleitmaterial

## Wozu IT-Grundwissen?

Computer, Netzwerke und Server sind die Infrastruktur der modernen Welt. Wer versteht, wie sie funktionieren, kann Probleme schneller loesen, Sicherheitsrisiken einschaetzen und mit Fachleuten auf Augenhoehe sprechen. Dieses Begleitmaterial vertieft die Themen der Lernkarten: Netzwerke, Betriebssysteme, Sicherheit, Container und Werkzeuge.


## Hardware-Grundlagen

### RAM und Festplatte -- zwei Arten von Speicher

Ein Computer hat zwei grundlegend verschiedene Arten von Speicher, und der Unterschied ist wichtig:

RAM (Random Access Memory), auch Arbeitsspeicher genannt, ist schnell und fluechtig. "Fluechtig" bedeutet: Wenn der Strom weg ist, sind die Daten weg. Im RAM laufen die aktiven Programme und werden die gerade benoetigten Daten gehalten. Typische Groessen: 8 bis 64 Gigabyte.

Die Festplatte (SSD oder HDD) ist langsamer, aber dauerhaft. Daten bleiben auch ohne Strom erhalten. Hier liegen das Betriebssystem, Programme und alle Dateien. Typische Groessen: 256 Gigabyte bis mehrere Terabyte.

Eine gute Analogie: RAM ist der Schreibtisch -- hier liegen die Sachen, an denen du gerade arbeitest. Die Festplatte ist der Aktenschrank -- hier lagerst du alles, was du nicht sofort brauchst, aber aufheben willst.

Der Unterschied zwischen HDD und SSD: Eine HDD (Hard Disk Drive) hat mechanische Teile -- rotierende Scheiben und einen Lesekopf, aehnlich einem Plattenspieler. Eine SSD (Solid State Drive) hat keine beweglichen Teile und speichert Daten elektronisch. SSDs sind deutlich schneller (vor allem beim zufaelligen Zugriff auf kleine Dateien), leiser, stromsparender und robuster gegen Erschuetterungen. Der Nachteil: Sie sind pro Gigabyte teurer.

### RAID -- mehrere Festplatten zusammenschalten

RAID steht fuer "Redundant Array of Independent Disks" und kombiniert mehrere Festplatten zu einem logischen Verbund. Je nach RAID-Level erreicht man mehr Geschwindigkeit, mehr Ausfallsicherheit oder beides.

RAID 0 (Striping): Daten werden abwechselnd auf zwei oder mehr Platten verteilt. Das verdoppelt die Geschwindigkeit, weil beide Platten gleichzeitig lesen und schreiben. Aber: Faellt eine Platte aus, sind alle Daten weg. RAID 0 bietet also Geschwindigkeit auf Kosten der Sicherheit.

RAID 1 (Spiegelung): Dieselben Daten werden auf zwei Platten geschrieben. Faellt eine aus, hat die andere noch alles. Der Nachteil: Man verliert die Haelfte der Gesamtkapazitaet. Zwei 1-TB-Platten im RAID 1 ergeben nur 1 TB nutzbaren Speicher.

RAID 5 (Striping mit Paritaet): Benoetigt mindestens drei Platten. Daten und Pruefinformationen (Paritaet) werden ueber alle Platten verteilt. Eine Platte darf ausfallen, die Daten bleiben erhalten und koennen beim Einsetzen einer neuen Platte rekonstruiert werden.

RAID 10 (Kombination aus 1 und 0): Mindestens vier Platten. Daten werden gespiegelt und gestreift. Das bietet sowohl Geschwindigkeit als auch Sicherheit, ist aber die teuerste Loesung.

Wichtig: RAID ist kein Backup. RAID schuetzt gegen den Ausfall einer Festplatte. Es schuetzt nicht gegen versehentliches Loeschen, Verschluesselungstrojaner oder einen Brand im Serverraum. Fuer echte Sicherheit braucht man beides: RAID fuer Verfuegbarkeit und Backups fuer Datensicherung.


## Netzwerk-Grundlagen

### IP-Adressen -- die Postadresse im Netzwerk

Jedes Geraet in einem Netzwerk braucht eine eindeutige Adresse, damit Datenpakete den richtigen Empfaenger finden. Diese Adresse ist die IP-Adresse.

IPv4-Adressen bestehen aus vier Zahlen zwischen 0 und 255, getrennt durch Punkte: zum Beispiel 192.168.1.100. Das sind 32 Bit, was rund 4,3 Milliarden moegliche Adressen ergibt. Das klingt viel, reicht aber laengst nicht mehr fuer alle Geraete weltweit.

Deshalb gibt es IPv6 mit 128 Bit: 2001:0db8:85a3::8a2e:0370:7334. Das sind 340 Sextillionen Adressen -- genug fuer jedes Sandkorn auf der Erde und noch viel mehr. IPv6 wird seit Jahren schrittweise eingefuehrt, ist aber noch nicht ueberall Standard.

Im lokalen Netzwerk zu Hause verwenden Geraete private IP-Adressen, typischerweise im Bereich 192.168.x.x. Diese Adressen sind nur innerhalb des eigenen Netzwerks gueltig. Der Router ueberssetzt sie in eine oeffentliche IP-Adresse fuer die Kommunikation mit dem Internet -- das nennt man NAT (Network Address Translation).

### Ports -- die Wohnungsnummer

Wenn die IP-Adresse die Hausnummer ist, dann ist der Port die Wohnungsnummer. Ein Server kann viele verschiedene Dienste gleichzeitig anbieten, und der Port bestimmt, welcher Dienst gemeint ist.

Ports sind Nummern von 0 bis 65535. Einige sind standardisiert:

- Port 80: HTTP (unverschluesseltes Web)
- Port 443: HTTPS (verschluesseltes Web)
- Port 22: SSH (sichere Fernverbindung)
- Port 25: SMTP (E-Mail-Versand)
- Port 53: DNS (Namensaufloesung)
- Port 3306: MySQL (Datenbank)

Wenn du im Browser "https://example.com" eingibst, verbindet sich der Browser automatisch mit Port 443. Du kannst den Port aber auch explizit angeben: "http://localhost:8080" verbindet sich mit Port 8080 auf dem eigenen Rechner.

### DNS -- das Telefonbuch des Internets

DNS steht fuer Domain Name System. Es uebersetzt die fuer Menschen lesbaren Domainnamen (wie "google.de") in IP-Adressen (wie 142.250.185.99), die Computer brauchen.

Der Ablauf, wenn du eine URL eingibst:

1. Dein Browser prueft seinen lokalen DNS-Cache -- vielleicht hat er die Adresse kuerzlich schon einmal nachgeschlagen.
2. Falls nicht gefunden, fragt er den DNS-Resolver deines Internetanbieters.
3. Der Resolver fragt sich durch die Hierarchie: Zuerst einen Root-Server ("Wer ist fuer .de zustaendig?"), dann den .de-Server ("Wer ist fuer google.de zustaendig?"), dann den zustaendigen Server fuer google.de.
4. Die IP-Adresse kommt zurueck und wird fuer kuenftige Anfragen zwischengespeichert.

Ohne DNS muestest du dir fuer jede Webseite die IP-Adresse merken. DNS ist also eine Komfortschicht, die das Internet bedienbar macht.

### TCP und UDP -- zwei Wege der Datenuebertragung

TCP (Transmission Control Protocol) und UDP (User Datagram Protocol) sind die beiden wichtigsten Transportprotokolle im Internet.

TCP ist verbindungsorientiert und zuverlaessig. Bevor Daten gesendet werden, bauen Sender und Empfaenger eine Verbindung auf (der sogenannte "Drei-Wege-Handshake"). TCP garantiert, dass alle Pakete ankommen und in der richtigen Reihenfolge zusammengesetzt werden. Wenn ein Paket verloren geht, wird es erneut gesendet. Das macht TCP zuverlaessig, aber langsamer. Einsatz: Webseiten, E-Mail, Dateiuebertragungen -- ueberall dort, wo Vollstaendigkeit wichtig ist.

UDP ist verbindungslos und schnell. Pakete werden einfach abgeschickt, ohne Bestaetigung. Wenn ein Paket verloren geht, wird es nicht erneut gesendet. Das macht UDP schneller, aber weniger zuverlaessig. Einsatz: Video-Streaming, Online-Gaming, DNS-Abfragen -- ueberall dort, wo Geschwindigkeit wichtiger ist als Vollstaendigkeit. Bei einem Video-Stream ist es besser, ein Bild zu ueberspringen, als auf die erneute Uebertragung zu warten.

Analogie: TCP ist wie ein Einschreiben -- du bekommst eine Bestaetigung, dass der Brief angekommen ist. UDP ist wie eine Postkarte -- du wirfst sie ein und hoffst, dass sie ankommt.

### Was passiert, wenn du eine URL eingibst?

Der komplette Ablauf, Schritt fuer Schritt:

1. Du tippst "https://example.com/seite" in die Adresszeile.
2. Der Browser parst die URL: Protokoll (HTTPS), Domain (example.com), Pfad (/seite).
3. DNS-Aufloesung: Die Domain wird in eine IP-Adresse uebersetzt.
4. TCP-Verbindung: Der Browser baut eine Verbindung zum Server auf (Port 443 fuer HTTPS).
5. TLS-Handshake: Die Verschluesselung wird ausgehandelt (dazu gleich mehr).
6. HTTP-Request: Der Browser schickt eine Anfrage ("GET /seite").
7. Der Server verarbeitet die Anfrage und schickt eine Antwort zurueck: den HTML-Code der Seite.
8. Der Browser parst das HTML. Dabei findet er Verweise auf CSS-Dateien, JavaScript-Dateien und Bilder -- die werden in weiteren Anfragen nachgeladen.
9. Der Browser baut den DOM-Baum, berechnet das Layout und rendert die Seite.

Das alles passiert in wenigen hundert Millisekunden.


## Sicherheit

### Die drei Saeulen der IT-Sicherheit (CIA-Triade)

IT-Sicherheit ruht auf drei Saeulen, die im Englischen als CIA-Triade bekannt sind:

Vertraulichkeit (Confidentiality): Nur berechtigte Personen haben Zugriff auf Informationen. Mittel: Verschluesselung, Zugriffsrechte, Authentifizierung. Beispiel: Deine E-Mails soll nur du lesen koennen, nicht jeder, der im selben WLAN sitzt.

Integritaet (Integrity): Daten werden nicht unbemerkt veraendert. Mittel: Pruefsummen (Hashes), digitale Signaturen. Beispiel: Wenn du eine Datei herunterlaeadst, willst du sicher sein, dass sie nicht manipuliert wurde.

Verfuegbarkeit (Availability): Systeme und Daten sind erreichbar, wenn sie gebraucht werden. Mittel: Redundanz (RAID, mehrere Server), Backups, Monitoring, DDoS-Schutz. Beispiel: Ein Online-Shop muss auch am Black Friday erreichbar sein.

Gute IT-Sicherheit beruecksichtigt alle drei Aspekte gleichzeitig. Ein System, das perfekt verschluesselt ist, aber staendig abstuerzt, hat ein Verfuegbarkeitsproblem. Ein System, das immer laeuft, aber dessen Daten jeder lesen kann, hat ein Vertraulichkeitsproblem.

### Verschluesselung -- symmetrisch und asymmetrisch

Verschluesselung wandelt lesbare Daten (Klartext) in unlesbaren Code (Chiffretext) um. Nur wer den richtigen Schluessel hat, kann die Daten wieder lesbar machen.

Symmetrische Verschluesselung: Ein einziger Schluessel fuer sowohl Ver- als auch Entschluesselung. Das ist schnell und effizient. Das Problem: Wie uebertraegst du den Schluessel sicher zum Empfaenger? Wenn jemand den Schluessel abfaengt, kann er alles mitlesen. Beispiel: AES (Advanced Encryption Standard), der heutige Goldstandard.

Asymmetrische Verschluesselung: Zwei verschiedene Schluessel -- ein oeffentlicher und ein privater. Was mit dem oeffentlichen Schluessel verschluesselt wird, kann nur mit dem privaten Schluessel entschluesselt werden. Der oeffentliche Schluessel darf frei verteilt werden; den privaten behaeltst du fuer dich. Das loest das Schluesseltausch-Problem, ist aber langsamer. Beispiel: RSA, Ed25519.

In der Praxis werden beide Verfahren kombiniert: Asymmetrische Verschluesselung, um einen symmetrischen Sitzungsschluessel sicher auszutauschen, und dann symmetrische Verschluesselung fuer die eigentlichen Daten. Genau so funktioniert HTTPS.

### Der TLS-Handshake -- wie HTTPS funktioniert

Wenn du eine HTTPS-Webseite aufrufst, passiert im Hintergrund ein TLS-Handshake:

1. Dein Browser schickt ein "Hallo" an den Server und teilt mit, welche Verschluesselungsverfahren er unterstuetzt.
2. Der Server antwortet mit dem gewaehlten Verfahren und seinem Zertifikat. Das Zertifikat enthaelt den oeffentlichen Schluessel des Servers und wurde von einer Zertifizierungsstelle (CA) signiert.
3. Dein Browser prueft das Zertifikat: Ist es gueltig? Wurde es von einer vertrauenswuerdigen CA ausgestellt? Stimmt der Domainname ueberein?
4. Browser und Server einigen sich auf einen gemeinsamen Sitzungsschluessel (symmetrisch).
5. Ab jetzt laeuft die gesamte Kommunikation verschluesselt.

Das Zertifikat beweist, dass du wirklich mit dem echten Server sprichst und nicht mit einem Angreifer, der sich dazwischengeschaltet hat (Man-in-the-Middle-Angriff).

### SSH-Schluessel -- passwortloses Anmelden

SSH (Secure Shell) ist das Standardprotokoll fuer sichere Verbindungen zu entfernten Servern. Statt jedes Mal ein Passwort einzugeben, kannst du SSH-Schluessel verwenden.

Du erzeugst ein Schluesselpaar auf deinem Rechner:

    ssh-keygen -t ed25519

Das erstellt zwei Dateien:
- ~/.ssh/id_ed25519 -- der private Schluessel. Den darfst du niemals weitergeben.
- ~/.ssh/id_ed25519.pub -- der oeffentliche Schluessel. Den traegst du auf dem Server ein.

Auf dem Server fuegtst du deinen oeffentlichen Schluessel in die Datei ~/.ssh/authorized_keys ein. Danach kannst du dich verbinden, ohne ein Passwort einzugeben. Der Server prueft, ob dein privater Schluessel zum hinterlegten oeffentlichen Schluessel passt.

Ed25519 ist der aktuell empfohlene Algorithmus: schnell, sicher und erzeugt kurze Schluessel.

### Firewalls -- Netzwerkverkehr kontrollieren

Eine Firewall kontrolliert, welcher Netzwerkverkehr ein System erreichen darf und welcher blockiert wird. Sie arbeitet mit Regeln: "Erlaube eingehende Verbindungen auf Port 22 (SSH)" oder "Blockiere alles von IP-Adresse X".

Unter Linux ist ufw (Uncomplicated Firewall) das einfachste Werkzeug:

    sudo ufw enable                 -- Firewall einschalten
    sudo ufw allow 22/tcp           -- SSH erlauben
    sudo ufw allow 80,443/tcp       -- Web erlauben
    sudo ufw deny 3306              -- MySQL von aussen blockieren
    sudo ufw status                 -- Aktuelle Regeln anzeigen

Die Grundregel: Alles blockieren, was nicht explizit erlaubt ist (Whitelist-Ansatz). Das ist sicherer als alles zu erlauben und nur bekannte Bedrohungen zu blockieren (Blacklist-Ansatz).


## Linux-Essentials

### Die wichtigsten Befehle

Linux-Server werden ueber die Kommandozeile (Terminal) bedient. Wer die folgenden Befehle kennt, kann die meisten alltaeglichen Serveraufgaben erledigen:

- ls -- Verzeichnisinhalt auflisten. "ls -la" zeigt auch versteckte Dateien und Details.
- cd -- Verzeichnis wechseln. "cd /var/log" springt ins Log-Verzeichnis.
- cat -- Dateiinhalt anzeigen. "cat /etc/hostname" zeigt den Servernamen.
- cp -- Dateien kopieren. "cp datei.txt backup.txt" erstellt eine Kopie.
- mv -- Dateien verschieben oder umbenennen.
- rm -- Dateien loeschen. Vorsicht: kein Papierkorb. "rm -rf" loescht rekursiv und ohne Rueckfrage.
- grep -- Text in Dateien suchen. "grep 'error' /var/log/syslog" findet alle Zeilen mit "error".
- chmod -- Dateiberechtigungen aendern. "chmod 755 script.sh" macht ein Skript ausfuehrbar.
- ssh -- Sichere Verbindung zu einem entfernten Rechner herstellen.
- ps, top, htop -- Laufende Prozesse anzeigen und deren Ressourcenverbrauch beobachten.
- kill -- Einen Prozess beenden. "kill 1234" sendet ein Beendigungssignal an Prozess 1234.
- ping -- Erreichbarkeit eines Servers pruefen. "ping google.de" testet die Verbindung.
- curl -- HTTP-Anfragen von der Kommandozeile senden. "curl -v https://example.com" zeigt die gesamte Verbindung.
- sudo -- Einen Befehl mit Administratorrechten ausfuehren.

### Server-Erreichbarkeit pruefen

Wenn ein Dienst nicht funktioniert, ist systematisches Pruefen gefragt:

1. Ist der Server erreichbar? "ping server.de" -- wenn Antworten kommen, ist die Netzwerkverbindung in Ordnung.
2. Welchen Weg nehmen die Pakete? "traceroute server.de" zeigt jeden Netzwerkknoten auf dem Weg.
3. Ist der Port offen? "nc -zv server.de 80" prueft, ob Port 80 erreichbar ist.
4. Welche Ports hoeren auf dem Server? "ss -tlnp" zeigt alle offenen Ports und die zugehoerigen Programme.
5. Funktioniert der HTTP-Dienst? "curl -v http://server.de" testet eine vollstaendige HTTP-Verbindung.


## Container und Virtualisierung

### Docker-Container vs. Virtuelle Maschinen

Beide Technologien schaffen isolierte Umgebungen, aber auf grundlegend verschiedene Weise.

Eine virtuelle Maschine (VM) simuliert einen kompletten Computer mit eigenem Betriebssystem und eigenem Kernel. Sie ist schwer (mehrere Gigabyte), braucht Minuten zum Starten und bietet starke Isolation. Jede VM hat ihr eigenes Windows oder Linux mit allen Systemdiensten. Das ist, als wuerdest du ein komplett eigenes Haus bauen.

Ein Container teilt sich den Betriebssystem-Kernel mit dem Host. Er enthaelt nur die Anwendung und ihre Abhaengigkeiten -- kein eigenes Betriebssystem. Deshalb sind Container leichtgewichtig (Megabyte statt Gigabyte) und starten in Sekunden. Die Isolation ist schwaecher als bei einer VM, reicht aber fuer die meisten Anwendungsfaelle. Ein Container ist wie eine Wohnung in einem Mehrfamilienhaus: eigene vier Waende, aber geteilte Infrastruktur.

Docker ist die bekannteste Container-Plattform. Ein Docker-Image beschreibt, was im Container ist (Betriebssystem-Basis, installierte Software, Konfiguration). Aus einem Image koennen beliebig viele Container gestartet werden. docker-compose erlaubt es, mehrere Container als zusammenhaengendes System zu definieren und gemeinsam zu starten -- zum Beispiel eine Webanwendung mit Datenbank und Cache.

### Reverse Proxy

Ein Reverse Proxy sitzt zwischen den Clients (Browsern der Nutzer) und den Backend-Servern. Er nimmt alle eingehenden Anfragen entgegen und leitet sie an den richtigen Backend-Server weiter.

Einsatzgebiete:

- SSL-Terminierung: Der Reverse Proxy entschluesselt HTTPS und leitet intern per HTTP weiter. Die Backend-Server muessen sich nicht um Zertifikate kuemmern.
- Load Balancing: Anfragen werden auf mehrere Backend-Server verteilt, um die Last zu streuen.
- Caching: Haeufig angefragte Inhalte werden zwischengespeichert.
- Sicherheit: Die Backend-Server sind nicht direkt aus dem Internet erreichbar.

Beliebte Reverse Proxies: nginx, Caddy, Traefik, HAProxy.


## CI/CD -- automatisierte Software-Auslieferung

CI/CD steht fuer Continuous Integration und Continuous Delivery (oder Deployment). Es ist ein Ansatz, bei dem Software-Aenderungen automatisch gebaut, getestet und ausgeliefert werden.

Continuous Integration (CI): Jedes Mal, wenn ein Entwickler Code-Aenderungen in das gemeinsame Repository einpflegt (Commit/Push), laeuft automatisch eine Pipeline: Der Code wird kompiliert, automatische Tests werden ausgefuehrt, Code-Qualitaetspruefungen (Linting) laufen. Wenn etwas fehlschlaegt, wird das Team sofort benachrichtigt. So werden Fehler frueh erkannt, statt erst kurz vor einem Release.

Continuous Delivery (CD): Wenn die CI-Pipeline erfolgreich durchlaeuft, wird der Code automatisch in eine Staging-Umgebung bereitgestellt, wo manuelle Tests stattfinden koennen.

Continuous Deployment geht noch weiter: Erfolgreicher Code geht automatisch bis in die Produktion -- ohne manuellen Eingriff.

Werkzeuge: GitHub Actions, GitLab CI, Jenkins, CircleCI. Sie alle arbeiten mit Konfigurationsdateien, die beschreiben, welche Schritte in welcher Reihenfolge ausgefuehrt werden sollen.

### Open Source

Open Source bedeutet, dass der Quellcode einer Software oeffentlich einsehbar, nutzbar und veraenderbar ist. Jeder kann den Code lesen, Fehler finden, Verbesserungen beitragen und die Software fuer eigene Zwecke anpassen.

Die genauen Regeln legt die Lizenz fest. Die drei wichtigsten Lizenztypen:

- MIT: Sehr freizuegig. Man darf fast alles damit machen, auch die Software in kommerzielle Produkte einbauen.
- GPL: Copyleft. Wer die Software veraendert und weitergibt, muss den Quellcode ebenfalls offen legen.
- Apache 2.0: Aehnlich freizuegig wie MIT, aber mit explizitem Patentschutz.

Bekannte Open-Source-Projekte: Linux (Betriebssystem), Firefox (Browser), LibreOffice (Buerosoftware), PostgreSQL (Datenbank), Docker (Container-Plattform).


## Tipps zum Lernen mit den Karten

Das Technik-Paket ist breit aufgestellt. Ein empfohlener Lernpfad:

1. Starte mit den Grundlagen-Karten (K-001 bis K-003, K-011, K-012). Sie erklaeren IP-Adressen, RAM vs. Festplatte, Open Source, Container und Ports -- die Basiskonzepte, auf denen alles aufbaut.

2. Gehe zur Theorie (K-004 bis K-006, K-013, K-014). DNS, TCP vs. UDP, Verschluesselung, RAID und IPv4 vs. IPv6 vertiefen das Netzwerk- und Systemverstaendnis.

3. Die Praxis-Karten (K-007, K-008, K-015, K-016) sind hands-on: Linux-Prozesse, SSH-Schluessel, Firewall-Regeln, Server-Diagnose. Probiere die Befehle auf einem echten System aus, wenn du die Moeglichkeit hast.

4. Vertiefung (K-017, K-018) behandelt Reverse Proxies und CI/CD -- Themen, die im professionellen Umfeld allgegenwaertig sind.

5. Die Pruefungs-Karten (K-019, K-020) fragen das Gelernte kompakt ab: Linux-Befehle und die drei Saeulen der IT-Sicherheit.

Gerade bei Technik-Themen gilt: Lesen allein reicht nicht. Wenn du Zugang zu einem Linux-System hast (notfalls einer virtuellen Maschine oder einem Container), probiere die Befehle und Konzepte aus. Aktives Tun verankert Wissen viel tiefer als passives Lesen.
