# Technik-Grundlagen -- Begleitmaterial

## Überblick

Dieses Paket vermittelt IT-Grundwissen das jeder kennen sollte
der mit Computern, Netzwerken oder dem Internet arbeitet.

## Netzwerk-Grundlagen

Jedes Gerät im Netzwerk hat eine IP-Adresse (die "Hausnummer")
und kommuniziert über Ports (die "Wohnungsnummer").

DNS übersetzt lesbare Namen (google.de) in IP-Adressen.
TCP sorgt dafür dass Daten zuverlässig ankommen.
UDP ist schneller aber weniger zuverlässig.

## Sicherheit

Die drei Säulen: Vertraulichkeit, Integrität, Verfügbarkeit.

Verschlüsselung schützt Daten: Symmetrisch (ein Schlüssel)
oder asymmetrisch (Schlüsselpaar). HTTPS kombiniert beides.

SSH-Schlüssel ersetzen Passwörter für Server-Zugänge.
Firewalls kontrollieren welcher Netzwerkverkehr erlaubt ist.

## Systeme

Container (Docker) sind leichtgewichtige isolierte Umgebungen.
RAID kombiniert mehrere Festplatten für Geschwindigkeit oder Sicherheit.
CI/CD automatisiert das Testen und Ausliefern von Software.

## Linux-Essentials

Die wichtigsten Befehle: ls, cd, grep, chmod, ssh, ps, kill, ping, curl.
Wer diese beherrscht kann die meisten Server-Aufgaben erledigen.
