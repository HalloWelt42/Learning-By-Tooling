# Web-Programmierung -- FRAGEN
# 20 Karten zu HTML, CSS, JavaScript, APIs, Frameworks

---

```
K-001 | Grundlagen
Was sind die drei Grundtechnologien jeder Webseite und wofür ist jede zuständig?
```

---

```
K-002 | Grundlagen
Was ist der Unterschied zwischen einer ID und einer Klasse in HTML/CSS?
```

---

```
K-003 | Grundlagen
Was bedeutet "responsives Design" und wie erreicht man es?
```

---

```
K-004 | Theorie
Was ist das DOM (Document Object Model)?
```

---

```
K-005 | Theorie
Erkläre den Unterschied zwischen let, const und var in JavaScript.
```

---

```
K-006 | Theorie
Was ist ein Promise in JavaScript und wozu braucht man es?
```

---

```
K-007 | Praxis
Wie zentrierst du ein Element horizontal und vertikal mit CSS Flexbox?
```

---

```
K-008 | Praxis
Schreibe eine JavaScript-Funktion die prüft ob eine Zahl eine Primzahl ist.
```

---

```
K-009 | Praxis
Wie machst du einen API-Aufruf mit fetch() in JavaScript?
```

---

```
K-010 | Verfahren
Was ist der Unterschied zwischen SSR, CSR und SSG?
```

---

```
K-011 | Verfahren
Erkläre den Git-Workflow: Was passiert bei add, commit und push?
```

---

```
K-012 | Grundlagen
Was ist JSON und wie sieht es aus?
```

---

```
K-013 | Grundlagen
Was ist ein HTTP-Statuscode? Nenne die wichtigsten Gruppen.
```

---

```
K-014 | Theorie
Was ist der Unterschied zwischen == und === in JavaScript?
```

---

```
K-015 | Theorie
Was ist ein Callback, und warum kann er zum Problem werden?
```

---

```
K-016 | Praxis
Wie erstellst du ein CSS Grid mit 3 Spalten und automatischen Zeilen?
```

---

```
K-017 | Vertiefung
Was ist eine REST-API und welche Prinzipien hat sie?
```

---

```
K-018 | Vertiefung
Was ist CORS und warum blockiert der Browser bestimmte Anfragen?
```

---

```
K-019 | Pruefung
Nenne fünf semantische HTML-Elemente und erkläre ihren Zweck.
```

---

```
K-020 | Pruefung
Was ist der Unterschied zwischen localStorage, sessionStorage und Cookies?
```
