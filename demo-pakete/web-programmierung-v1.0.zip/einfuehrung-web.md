# Web-Programmierung -- Begleitmaterial

## Warum Web-Programmierung lernen?

Das Web ist die universellste Plattform, die es gibt. Eine Webanwendung laeuft auf jedem Geraet mit einem Browser -- egal ob Windows, Mac, Linux, Smartphone oder Tablet. Wer HTML, CSS und JavaScript versteht, kann Webseiten bauen, Webanwendungen entwickeln und APIs ansprechen. Dieses Begleitmaterial vertieft die Themen der Lernkarten und stellt die Zusammenhaenge her, die in einzelnen Karten zu kurz kommen.


## Die drei Grundtechnologien des Web

Jede Webseite basiert auf drei Technologien, die zusammenspielen:

- HTML (HyperText Markup Language) definiert die Struktur und den Inhalt: Ueberschriften, Absaetze, Links, Bilder, Formulare.
- CSS (Cascading Style Sheets) bestimmt das Aussehen: Farben, Schriftarten, Abstaende, Layout.
- JavaScript steuert das Verhalten: Reaktion auf Klicks, Daten laden, Inhalte aendern, Animationen.

Eine brauchbare Analogie: HTML ist das Skelett eines Gebaeudes (Struktur), CSS ist die Fassade und Inneneinrichtung (Aussehen), JavaScript sind die Aufzuege, Tueren und die Elektrik (Funktion).

Du kannst eine Webseite nur mit HTML bauen -- sie wird funktionieren, aber haesslich aussehen. Mit HTML und CSS wird sie huebsch, aber statisch. Erst JavaScript macht sie interaktiv.


## HTML -- Struktur und Inhalt

### Grundaufbau eines HTML-Dokuments

Ein HTML-Dokument ist eine verschachtelte Struktur aus Elementen. Jedes Element besteht aus einem oeffnenden Tag, dem Inhalt und einem schliessenden Tag. Zum Beispiel markiert ein Absatz-Element einen Textabsatz, eine Ueberschrift markiert eine Ueberschrift.

Die Grundstruktur jeder HTML-Seite umfasst:
- Die DOCTYPE-Deklaration (sagt dem Browser, dass es HTML5 ist)
- Das html-Element als Wurzel
- Den head-Bereich mit Metadaten (Titel, Zeichensatz, verknuepfte CSS-Dateien)
- Den body-Bereich mit dem sichtbaren Inhalt

### Semantische HTML-Elemente

Fruehe Webseiten bestanden fast nur aus generischen div-Elementen. Modernes HTML bietet semantische Elemente, die dem Browser und Screenreadern mitteilen, welche Rolle ein Bereich spielt:

- header: Kopfbereich der Seite oder eines Abschnitts. Typisch: Logo, Navigation, Seitentitel.
- nav: Navigationsbereich mit Menuepunkten und Links.
- main: Der Hauptinhalt der Seite. Darf nur einmal pro Seite vorkommen.
- article: Ein eigenstaendiger Inhalt, der fuer sich allein Sinn ergibt -- ein Blogpost, ein Nachrichtenartikel, ein Kommentar.
- section: Ein thematischer Abschnitt innerhalb einer Seite.
- aside: Ergaenzender Inhalt, der nicht zum Hauptfluss gehoert -- eine Seitenleiste, ein Infokasten.
- footer: Fussbereich der Seite oder eines Abschnitts. Typisch: Copyright, Impressum, Links.

Warum das wichtig ist: Screenreader fuer sehbehinderte Menschen nutzen diese Elemente zur Navigation. Und Suchmaschinen verstehen die Seitenstruktur besser, was sich positiv auf das Ranking auswirken kann (SEO).

### IDs und Klassen

Zwei Mechanismen, um HTML-Elemente gezielt anzusprechen:

IDs sind eindeutig pro Seite. Ein Element hat eine ID, kein anderes Element auf derselben Seite darf dieselbe ID haben. In CSS spricht man sie mit dem Rautezeichen an: #mein-element { ... }. In JavaScript mit document.getElementById('mein-element') oder document.querySelector('#mein-element').

Klassen sind wiederverwendbar. Mehrere Elemente koennen dieselbe Klasse haben, und ein Element kann mehrere Klassen haben. In CSS: .meine-klasse { ... }.

Faustregel: Klassen fuer Styling, IDs wenn du ein einziges konkretes Element ansprechen musst (zum Beispiel fuer JavaScript-Zugriff).


## CSS -- Aussehen und Layout

### Das Box-Modell

Jedes HTML-Element ist fuer CSS eine Box. Diese Box besteht aus vier Schichten:

1. Content: Der eigentliche Inhalt (Text, Bild).
2. Padding: Innenabstand zwischen Inhalt und Rahmen.
3. Border: Der sichtbare Rahmen.
4. Margin: Aussenabstand zu benachbarten Elementen.

Standardmaessig addiert CSS Padding und Border zur angegebenen Breite hinzu. Ein Element mit width: 200px und padding: 20px ist also tatsaechlich 240px breit. Das ist kontraintuitiv. Deshalb setzen die meisten Projekte "box-sizing: border-box" global -- dann sind Padding und Border in der angegebenen Breite enthalten.

### Flexbox -- eindimensionales Layout

CSS Flexbox ist fuer eindimensionale Layouts: entweder eine Zeile oder eine Spalte. Du setzt "display: flex" auf den Container, und die Kind-Elemente werden automatisch nebeneinander angeordnet.

Die wichtigsten Eigenschaften:

- flex-direction: Richtung (row fuer Zeile, column fuer Spalte).
- justify-content: Ausrichtung entlang der Hauptachse (center, space-between, space-around).
- align-items: Ausrichtung quer zur Hauptachse (center, flex-start, flex-end, stretch).
- gap: Abstand zwischen den Elementen.

Ein klassisches Problem: Ein Element horizontal und vertikal zentrieren. Mit Flexbox ist das trivial:

    .container {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

Drei Zeilen CSS loesen ein Problem, das frueher Workarounds mit Margins, Transforms oder Table-Display erforderte.

### CSS Grid -- zweidimensionales Layout

CSS Grid ist fuer zweidimensionale Layouts: Zeilen und Spalten gleichzeitig. Du definierst ein Raster, und die Kind-Elemente fuellen die Zellen.

Ein Grid mit drei gleich breiten Spalten:

    .container {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 16px;
    }

"1fr" bedeutet "ein Bruchteil des verfuegbaren Platzes". Drei mal 1fr ergibt drei gleich breite Spalten. "gap: 16px" setzt den Abstand zwischen den Zellen.

Fuer responsive Layouts gibt es eine elegante Loesung:

    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));

Das bedeutet: Fuelle so viele Spalten wie moeglich, jede mindestens 250px breit, maximal gleichmaessig verteilt. Auf einem breiten Bildschirm bekommst du vier oder fuenf Spalten, auf einem schmalen Handy-Bildschirm eine einzige.

### Responsive Design

Responsive Design bedeutet, dass eine Webseite sich automatisch an verschiedene Bildschirmgroessen anpasst -- ohne dass man separate Versionen fuer Handy, Tablet und Desktop bauen muss.

Die Werkzeuge dafuer:

- Der Viewport-Meta-Tag im HTML-Head: Er sorgt dafuer, dass der mobile Browser die Seite nicht verkleinert darstellt.
- Media Queries: CSS-Regeln, die nur ab einer bestimmten Bildschirmbreite gelten. Zum Beispiel: Ab 768px Breite zeige drei Spalten, darunter nur eine.
- Flexible Einheiten: Prozent (%), rem, em, vw (Viewport Width) statt fester Pixel. So passen sich Elemente an den verfuegbaren Platz an.
- Flexbox und Grid: Layout-Systeme, die von Natur aus flexibel sind.

Die Grundidee: Gestalte zuerst fuer kleine Bildschirme (Mobile First), und fuege dann mit Media Queries Anpassungen fuer groessere Bildschirme hinzu. Das ist einfacher als umgekehrt.


## JavaScript -- Verhalten und Logik

### Variablen: const, let und var

JavaScript kennt drei Schluesselwoerter zum Deklarieren von Variablen:

var: Der alte Standard aus den Anfangszeiten von JavaScript. Var hat Funktions-Scope, nicht Block-Scope. Das bedeutet: Eine mit var deklarierte Variable ist innerhalb der gesamten Funktion sichtbar, nicht nur innerhalb des Blocks (der geschweiften Klammern), in dem sie steht. Das fuehrt leicht zu Fehlern. Var sollte in neuem Code nicht mehr verwendet werden.

let: Block-Scope. Die Variable ist nur innerhalb des Blocks sichtbar, in dem sie deklariert wurde. Der Wert kann spaeter geaendert werden. Verwende let fuer Zaehler, Schleifenvariablen und Werte, die sich aendern muessen.

const: Block-Scope. Der Wert kann nach der Deklaration nicht mehr neu zugewiesen werden. Verwende const fuer alles, was sich nicht aendern soll: Konfigurationswerte, DOM-Referenzen, importierte Module. Achtung: const verhindert die Neuzuweisung, nicht die Veraenderung. Ein const-Objekt kann immer noch Eigenschaften geaendert bekommen -- nur die Variable selbst kann nicht auf ein anderes Objekt zeigen.

Faustregel: Immer const verwenden. Nur let nehmen, wenn du den Wert spaeter aendern musst. Nie var.

### Gleichheit: == vs. ===

JavaScript hat zwei Gleichheitsoperatoren, und der Unterschied ist eine haeufige Fehlerquelle:

== (lose Gleichheit) vergleicht Werte nach Typumwandlung. JavaScript versucht, die Werte in einen gemeinsamen Typ zu bringen, bevor es vergleicht. "5" == 5 ergibt true (der String "5" wird zur Zahl 5 konvertiert). 0 == false ergibt true. null == undefined ergibt true. Das fuehrt zu ueberraschenden und schwer findbaren Fehlern.

=== (strikte Gleichheit) vergleicht Wert und Typ ohne Umwandlung. "5" === 5 ergibt false (String ist nicht Zahl). 0 === false ergibt false (Zahl ist nicht Boolean).

Faustregel: Immer === verwenden. Es gibt fast keinen guten Grund fuer ==.

### Asynchrone Programmierung: Callbacks, Promises, async/await

JavaScript ist single-threaded -- es kann nur eine Sache gleichzeitig tun. Wenn eine Operation laenger dauert (Daten vom Server laden, Datei lesen, Timer abwarten), wuerde der gesamte Browser einfrieren, wenn JavaScript darauf warten muesste. Deshalb gibt es asynchrone Programmierung.

Callbacks: Die aelteste Loesung. Du uebergibst einer Funktion eine andere Funktion, die aufgerufen wird, wenn die Operation fertig ist. Das funktioniert fuer einfache Faelle, fuehrt aber bei mehreren verschachtelten Operationen zur sogenannten "Callback Hell" -- immer tiefer verschachtelte Funktionen, die kaum noch lesbar sind.

Promises: Die moderne Loesung. Ein Promise ist ein Objekt, das einen zukuenftigen Wert repraesentiert. Es hat drei Zustaende: "pending" (noch nicht fertig), "fulfilled" (erfolgreich) und "rejected" (fehlgeschlagen). Mit .then() reagierst du auf Erfolg, mit .catch() auf Fehler. Promises lassen sich verketten statt verschachteln.

async/await: Syntaktischer Zucker ueber Promises. Eine mit "async" markierte Funktion kann "await" verwenden, um auf ein Promise zu warten. Der Code liest sich dann fast wie synchroner Code, ist aber tatsaechlich asynchron. Das ist die empfohlene Schreibweise fuer modernen JavaScript-Code.

### Das DOM (Document Object Model)

Wenn der Browser ein HTML-Dokument laedt, baut er daraus eine Baumstruktur -- das DOM. Jedes HTML-Element wird ein Knoten im Baum. JavaScript kann diesen Baum lesen und veraendern, und der Browser aktualisiert die Darstellung entsprechend.

document.querySelector('.meine-klasse') findet das erste Element mit dieser Klasse. document.querySelectorAll('p') findet alle Absaetze. Ueber die gefundenen Elemente kannst du den Text aendern (textContent), Klassen hinzufuegen oder entfernen (classList), Attribute setzen und Ereignis-Listener anbringen.

Das DOM ist die Schnittstelle zwischen HTML und JavaScript. Wenn du verstehst, dass der Browser HTML in einen Baum umwandelt und JavaScript diesen Baum manipuliert, verstehst du die Grundlage aller interaktiven Webseiten.


## APIs und Datenformate

### JSON -- das Datenaustauschformat des Web

JSON (JavaScript Object Notation) ist ein textbasiertes Format zum Speichern und Uebertragen von Daten. Es ist der Standard fuer Web-APIs.

Ein JSON-Objekt besteht aus Schluessel-Wert-Paaren in geschweiften Klammern. Schluessel muessen in doppelten Anfuehrungszeichen stehen. Werte koennen Strings, Zahlen, Booleans, Arrays (Listen) oder verschachtelte Objekte sein.

Regeln: Schluessel immer in doppelten Anfuehrungszeichen. Kein abschliessendes Komma nach dem letzten Element. Keine Kommentare erlaubt.

In JavaScript wandelst du Objekte mit JSON.stringify() in JSON-Strings um und mit JSON.parse() zurueck.

### REST-APIs

REST (Representational State Transfer) ist ein Architekturstil fuer Web-APIs. Die Grundidee: Alles ist eine Ressource, und jede Ressource hat eine URL.

Die HTTP-Methoden bestimmen die Aktion:

- GET: Daten abrufen. "GET /api/users" gibt die Liste aller Benutzer zurueck.
- POST: Neue Daten erstellen. "POST /api/users" mit JSON-Body erstellt einen neuen Benutzer.
- PUT: Bestehende Daten aktualisieren. "PUT /api/users/42" aktualisiert den Benutzer mit ID 42.
- DELETE: Daten loeschen. "DELETE /api/users/42" loescht den Benutzer mit ID 42.

REST-APIs sind zustandslos: Jede Anfrage enthaelt alle Informationen, die der Server braucht. Der Server merkt sich nichts zwischen zwei Anfragen (ausser ueber Tokens oder Session-IDs, die der Client mitschickt).

### HTTP-Statuscodes

Der Server antwortet auf jede Anfrage mit einem dreistelligen Statuscode. Die fuenf Gruppen:

- 1xx: Informational (selten in der Praxis).
- 2xx: Erfolg. 200 OK (alles gut), 201 Created (Ressource wurde erstellt), 204 No Content (erfolgreich, aber keine Daten zurueck).
- 3xx: Weiterleitung. 301 Moved Permanently (Seite ist umgezogen), 304 Not Modified (Daten haben sich nicht geaendert, Cache verwenden).
- 4xx: Client-Fehler. 400 Bad Request (fehlerhafte Anfrage), 401 Unauthorized (nicht authentifiziert), 403 Forbidden (keine Berechtigung), 404 Not Found (gibt es nicht).
- 5xx: Server-Fehler. 500 Internal Server Error (der Server hat ein Problem), 502 Bad Gateway (ein Zwischenserver hat ein Problem), 503 Service Unavailable (Server ist ueberlastet oder in Wartung).

### fetch() -- API-Aufrufe in JavaScript

Die fetch()-Funktion ist der moderne Weg, HTTP-Anfragen aus JavaScript zu senden. Sie gibt ein Promise zurueck.

Eine GET-Anfrage:

    const response = await fetch('https://api.example.com/daten')
    const data = await response.json()

Eine POST-Anfrage:

    const response = await fetch('https://api.example.com/daten', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: 'Test', wert: 42 })
    })

Wichtig: fetch() wirft keinen Fehler bei 404 oder 500. Du musst response.ok pruefen, um festzustellen, ob die Anfrage erfolgreich war.

### CORS -- warum der Browser blockiert

CORS (Cross-Origin Resource Sharing) ist ein Sicherheitsmechanismus des Browsers. Er verhindert, dass eine Webseite auf einer Domain (z.B. meine-seite.de) ohne Erlaubnis Anfragen an eine andere Domain (z.B. api.example.com) stellt.

Warum? Ohne CORS koennte eine boesartige Webseite im Namen des eingeloggten Benutzers Anfragen an dessen Bank, E-Mail oder soziales Netzwerk senden.

Wie CORS funktioniert: Bevor der Browser eine Cross-Origin-Anfrage durchfuehrt, schickt er eine "Preflight"-Anfrage (OPTIONS) an den Server und fragt: "Darf meine-seite.de auf dich zugreifen?" Der Server antwortet mit CORS-Headern:

- Access-Control-Allow-Origin: Welche Domains duerfen zugreifen?
- Access-Control-Allow-Methods: Welche HTTP-Methoden sind erlaubt?
- Access-Control-Allow-Headers: Welche Header duerfen gesendet werden?

In der Entwicklung setzt man oft "Access-Control-Allow-Origin: *" (alles erlauben). In der Produktion sollte man nur die eigene Domain erlauben.


## Rendering-Strategien

### SSR, CSR und SSG

Es gibt drei grundlegende Ansaetze, wie eine Webseite dem Nutzer ausgeliefert wird:

Server-Side Rendering (SSR): Der Server generiert bei jeder Anfrage fertiges HTML. Der Browser bekommt eine komplette Seite und kann sie sofort anzeigen. Vorteil: Schneller erster Seitenaufruf, gut fuer Suchmaschinen (SEO). Nachteil: Der Server muss bei jeder Anfrage arbeiten. Beispiele: Next.js, SvelteKit, PHP.

Client-Side Rendering (CSR): Der Server liefert ein fast leeres HTML-Dokument und eine grosse JavaScript-Datei. Der Browser fuehrt das JavaScript aus und baut die Seite selbst zusammen. Vorteil: Nach dem ersten Laden fuehlt sich die Navigation schnell an, weil nur Daten nachgeladen werden, keine ganzen Seiten. Nachteil: Der erste Seitenaufruf dauert laenger, und Suchmaschinen sehen zunaechst eine leere Seite. Beispiele: React SPA, Vue SPA.

Static Site Generation (SSG): Alle Seiten werden einmalig beim Build-Prozess als statische HTML-Dateien erzeugt. Kein Server noetig -- die Dateien koennen direkt von einem CDN ausgeliefert werden. Vorteil: Extrem schnell, einfach zu hosten, sicher (kein Server, der angegriffen werden kann). Nachteil: Fuer dynamische Inhalte (Kommentare, Warenkorb) braucht man zusaetzliche Loesungen. Beispiele: Astro, Hugo, Eleventy.


## Werkzeuge

### Git -- Versionskontrolle

Git ist das Standardwerkzeug fuer Versionskontrolle in der Softwareentwicklung. Es speichert die komplette Historie aller Aenderungen an deinem Code.

Der grundlegende Workflow:

1. Du aenderst Dateien in deinem Arbeitsverzeichnis.
2. "git add datei.js" nimmt die Aenderungen in die Staging Area auf. Das ist eine Zwischenstufe: Du bestimmst, welche Aenderungen in den naechsten Commit sollen.
3. "git commit -m 'Beschreibung'" erstellt einen Snapshot aller gestagten Aenderungen. Ein Commit ist dauerhaft und enthaelt die Aenderungen, eine Nachricht, den Autor und einen Zeitstempel.
4. "git push" schickt die lokalen Commits zum Remote-Repository (z.B. auf GitHub oder GitLab). Erst danach sehen andere Entwickler deine Aenderungen.

Die Reihenfolge ist immer: Aendern, add, commit, push. Du kannst mehrere Aenderungen sammeln (mehrere adds), bevor du einen Commit machst.

Branches erlauben es, parallel an verschiedenen Features zu arbeiten, ohne sich gegenseitig zu stoeren. Ein Branch ist eine eigenstaendige Entwicklungslinie. Wenn das Feature fertig ist, wird der Branch zurueck in den Hauptbranch (main oder master) zusammengefuehrt (Merge).

### npm -- Paketverwaltung

npm (Node Package Manager) ist der Paketmanager fuer JavaScript. Er installiert und verwaltet Bibliotheken (Pakete), die dein Projekt benoetigt.

Die wichtigsten Befehle:

- npm install: Installiert alle Abhaengigkeiten, die in der Datei package.json definiert sind.
- npm install paketname: Installiert ein bestimmtes Paket und fuegt es zu package.json hinzu.
- npm run dev: Startet den Entwicklungsserver (der genaue Befehl ist in package.json unter "scripts" definiert).
- npm run build: Erstellt eine optimierte Version fuer die Produktion.

Die Datei package.json ist das Herzstuck: Sie listet alle Abhaengigkeiten und definiert Skripte (Befehle). Die Datei package-lock.json fixiert die genauen Versionen aller Pakete, damit jeder Entwickler exakt dieselben Versionen bekommt.

Der Ordner node_modules enthaelt die installierten Pakete. Er kann sehr gross werden (Hunderte von Megabyte) und wird nie ins Git-Repository eingecheckt -- stattdessen fuehrt jeder Entwickler "npm install" aus, um ihn lokal neu zu erzeugen.

### Browser DevTools

Die Entwicklerwerkzeuge des Browsers (F12 oder Cmd+Option+I) sind das wichtigste Debugging-Werkzeug fuer Web-Entwickler.

- Elements/Inspector: Zeigt den aktuellen DOM-Baum. Du kannst Elemente anklicken und ihre CSS-Eigenschaften sehen und live aendern.
- Console: Zeigt JavaScript-Fehler und Log-Ausgaben. Du kannst auch eigenen JavaScript-Code eingeben und ausfuehren.
- Network: Zeigt alle HTTP-Anfragen, die die Seite macht. Du siehst die URL, Methode, Statuscode, Groesse, Dauer und den Response-Body. Unverzichtbar beim Debugging von API-Aufrufen.
- Application/Storage: Zeigt localStorage, sessionStorage, Cookies und andere gespeicherte Daten.

### Speicher im Browser

Der Browser bietet drei Mechanismen zum Speichern von Daten auf der Client-Seite:

localStorage: Daten bleiben dauerhaft gespeichert, auch nach dem Schliessen des Browsers. Kapazitaet etwa 5-10 MB. Speichert nur Strings (Objekte muessen mit JSON.stringify() umgewandelt werden). Zugriff nur von derselben Domain. Typischer Einsatz: Benutzereinstellungen, Theme-Wahl.

sessionStorage: Daten gelten nur fuer die aktuelle Browser-Session. Sobald der Tab geschlossen wird, sind sie weg. Kapazitaet etwa 5 MB. Sonst identisch mit localStorage. Typischer Einsatz: Temporaere Formulardaten, Zwischenstaende.

Cookies: Werden bei jeder HTTP-Anfrage automatisch zum Server mitgeschickt. Maximal 4 KB. Haben ein Ablaufdatum. Typischer Einsatz: Session-IDs, Authentifizierung. Wichtig: Sicherheitsattribute setzen -- HttpOnly (kein Zugriff per JavaScript), Secure (nur ueber HTTPS), SameSite (Schutz vor CSRF-Angriffen).


## Tipps zum Lernen mit den Karten

Das Web-Programmierung-Paket ist praxisorientiert. Empfohlener Lernpfad:

1. Starte mit den Grundlagen-Karten (K-001 bis K-003, K-012, K-013). Sie behandeln die drei Grundtechnologien, IDs vs. Klassen, responsives Design, JSON und HTTP-Statuscodes.

2. Gehe zur Theorie (K-004 bis K-006, K-014, K-015). DOM, let/const/var, Promises, == vs. ===, Callbacks -- das sind die Konzepte, die du wirklich verstehen musst, um JavaScript produktiv einzusetzen.

3. Die Praxis-Karten (K-007 bis K-009, K-016) sind am wertvollsten, wenn du sie am Rechner nachvollziehst: Flexbox-Zentrierung, Primzahl-Funktion, fetch()-Aufrufe, CSS Grid. Oeffne die Browser-Konsole und probiere den Code aus.

4. Verfahren und Vertiefung (K-010, K-011, K-017, K-018) behandeln den groesseren Kontext: SSR vs. CSR, Git-Workflow, REST-APIs, CORS.

5. Die Pruefungs-Karten (K-019, K-020) testen, ob du semantisches HTML und Browser-Speicher-Mechanismen verinnerlicht hast.

Web-Programmierung lernt man am besten durch Bauen. Nimm dir ein kleines Projekt vor -- eine persoenliche Webseite, eine ToDo-App, eine Wetteranzeige mit API-Anbindung -- und setze das Gelernte direkt um. Jede Stunde aktives Programmieren bringt mehr als zehn Stunden reines Lesen.
