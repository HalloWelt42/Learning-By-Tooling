# Web-Programmierung -- Begleitmaterial

## Die drei Säulen des Web

Jede Webseite basiert auf drei Technologien:
HTML für Struktur, CSS für Aussehen, JavaScript für Verhalten.

## HTML: Struktur

HTML beschreibt WAS auf der Seite steht.
Semantische Elemente (header, nav, main, article, footer)
helfen Browsern und Screenreadern die Seite zu verstehen.

IDs sind eindeutig pro Seite, Klassen sind wiederverwendbar.

## CSS: Layout

Flexbox für eindimensionale Layouts (Zeile oder Spalte).
Grid für zweidimensionale Layouts (Zeilen UND Spalten).
Media Queries für responsive Anpassungen.

Flexible Einheiten (%, rem, vw) statt fester Pixel.

## JavaScript: Logik

const für unveränderliche Werte, let für veränderliche.
Promises und async/await für asynchrone Operationen.
fetch() für API-Aufrufe.
DOM-Manipulation über querySelector und textContent.

## APIs und Datenformate

REST-APIs nutzen HTTP-Methoden: GET, POST, PUT, DELETE.
JSON ist das Standardformat für Datenaustausch.
HTTP-Statuscodes signalisieren Erfolg (2xx) oder Fehler (4xx/5xx).
CORS schützt vor unerlaubten Cross-Origin-Anfragen.

## Werkzeuge

Git (Versionskontrolle): add, commit, push.
npm (Paketverwaltung): install, run dev, run build.
Browser DevTools: Elemente inspizieren, Netzwerk, Konsole.

## Speicher im Browser

localStorage für dauerhafte Daten (Einstellungen).
sessionStorage für temporäre Daten (aktuelle Sitzung).
Cookies für Server-Kommunikation (Authentifizierung).
