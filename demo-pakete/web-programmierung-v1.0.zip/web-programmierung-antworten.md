# Web-Programmierung -- ANTWORTEN

---

```
A-001 | Grundlagen -> K-001
1. HTML (HyperText Markup Language): Struktur und Inhalt.
   Überschriften, Absätze, Links, Bilder, Formulare.

2. CSS (Cascading Style Sheets): Aussehen und Layout.
   Farben, Schriftarten, Abstände, Positionierung.

3. JavaScript: Verhalten und Interaktion.
   Klick-Ereignisse, Animationen, Daten laden, DOM verändern.

HTML = Skelett, CSS = Kleidung, JavaScript = Muskeln.
```

---

```
A-002 | Grundlagen -> K-002
ID (#): Eindeutig pro Seite. Ein Element hat eine ID,
kein anderes Element darf dieselbe haben.
CSS: #mein-element { ... }

Klasse (.): Wiederverwendbar. Mehrere Elemente können
dieselbe Klasse haben, ein Element kann mehrere Klassen haben.
CSS: .meine-klasse { ... }

Faustregel: Klassen für Styling, IDs für JavaScript-Zugriff.
```

---

```
A-003 | Grundlagen -> K-003
Responsives Design passt sich automatisch an die Bildschirmgröße an.
Dieselbe Seite sieht auf Handy, Tablet und Desktop gut aus.

Mittel:
- Media Queries: @media (max-width: 768px) { ... }
- Flexible Einheiten: %, vw, vh, em, rem statt feste px
- CSS Flexbox und Grid: Flexible Layouts
- Meta-Viewport-Tag: <meta name="viewport" content="width=device-width">
```

---

```
A-004 | Theorie -> K-004
Das DOM ist die Baumstruktur die der Browser aus dem HTML erstellt.
Jedes HTML-Element wird ein Knoten (Node) im Baum.

Beispiel:
<html>
  <body>
    <h1>Titel</h1>
    <p>Text</p>
  </body>
</html>

JavaScript kann den DOM lesen und verändern:
document.querySelector('h1').textContent = 'Neuer Titel'

Der Browser rendert immer den aktuellen DOM-Zustand.
```

---

```
A-005 | Theorie -> K-005
var: Alter Standard. Funktions-Scope (nicht Block-Scope).
Kann versehentlich überschrieben werden. Nicht mehr verwenden.

let: Block-Scope (innerhalb von { }). Kann neu zugewiesen werden.
Für Werte die sich ändern: Zähler, Zwischenergebnisse.

const: Block-Scope. Kann NICHT neu zugewiesen werden.
Für Werte die gleich bleiben: Konfiguration, DOM-Referenzen.

Faustregel: Immer const, nur let wenn nötig, nie var.
```

---

```
A-006 | Theorie -> K-006
Ein Promise repräsentiert einen Wert der jetzt noch nicht
verfügbar ist aber in Zukunft sein wird (oder fehlschlägt).

Drei Zustände:
- pending: Noch nicht fertig
- fulfilled: Erfolgreich abgeschlossen
- rejected: Fehlgeschlagen

Beispiel:
fetch('/api/daten')
  .then(response => response.json())
  .then(data => console.log(data))
  .catch(error => console.error(error))

Oder mit async/await:
const response = await fetch('/api/daten')
const data = await response.json()
```

---

```
A-007 | Praxis -> K-007
.container {
  display: flex;
  justify-content: center;   /* horizontal */
  align-items: center;        /* vertikal */
  height: 100vh;              /* volle Bildschirmhöhe */
}

Oder mit CSS Grid:
.container {
  display: grid;
  place-items: center;
  height: 100vh;
}
```

---

```
A-008 | Praxis -> K-008
function istPrimzahl(n) {
  if (n <= 1) return false
  if (n <= 3) return true
  if (n % 2 === 0) return false
  for (let i = 3; i * i <= n; i += 2) {
    if (n % i === 0) return false
  }
  return true
}

Trick: Nur bis zur Wurzel von n prüfen.
Gerade Zahlen (außer 2) direkt ausschließen.
```

---

```
A-009 | Praxis -> K-009
// GET-Anfrage
const response = await fetch('https://api.example.com/daten')
const data = await response.json()

// POST-Anfrage
const response = await fetch('https://api.example.com/daten', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ name: 'Test', wert: 42 })
})

Immer Fehler abfangen:
if (!response.ok) throw new Error('HTTP ' + response.status)
```

---

```
A-010 | Verfahren -> K-010
SSR (Server-Side Rendering):
Server generiert fertiges HTML bei jeder Anfrage.
Schnell für den ersten Seitenaufruf, gut für SEO.
Beispiele: PHP, Next.js, SvelteKit.

CSR (Client-Side Rendering):
Server liefert leeres HTML + JavaScript.
Browser baut die Seite selbst auf.
Schnelle Navigation nach dem ersten Laden.
Beispiele: React SPA, Vue SPA.

SSG (Static Site Generation):
HTML wird einmalig beim Build erzeugt.
Kein Server nötig, extrem schnell.
Beispiele: Astro, Hugo, 11ty.
```

---

```
A-011 | Verfahren -> K-011
git add datei.js
Nimmt Änderungen in die "Staging Area" auf.
Markiert welche Änderungen in den nächsten Commit sollen.

git commit -m "Beschreibung"
Erstellt einen Snapshot aller gestagten Änderungen.
Wird lokal gespeichert mit Nachricht, Autor, Zeitstempel.

git push
Schickt die lokalen Commits zum Remote-Repository (z.B. GitHub).
Erst danach sehen andere die Änderungen.

Reihenfolge: Ändern -> add -> commit -> push.
```

---

```
A-012 | Grundlagen -> K-012
JSON (JavaScript Object Notation) ist ein textbasiertes Datenformat.

Beispiel:
{
  "name": "Max",
  "alter": 30,
  "sprachen": ["Deutsch", "Englisch"],
  "adresse": {
    "stadt": "Berlin",
    "plz": "10115"
  }
}

Regeln: Schlüssel in doppelten Anführungszeichen,
kein Trailing Comma, kein Kommentar erlaubt.
Standard für Web-APIs.
```

---

```
A-013 | Grundlagen -> K-013
HTTP-Statuscodes sind dreistellige Zahlen die der Server
als Antwort auf eine Anfrage zurückgibt.

1xx: Information (selten genutzt)
2xx: Erfolg
  200 OK, 201 Created, 204 No Content
3xx: Weiterleitung
  301 Moved Permanently, 304 Not Modified
4xx: Client-Fehler
  400 Bad Request, 401 Unauthorized, 403 Forbidden, 404 Not Found
5xx: Server-Fehler
  500 Internal Server Error, 502 Bad Gateway, 503 Service Unavailable
```

---

```
A-014 | Theorie -> K-014
== (lose Gleichheit):
Vergleicht Werte NACH Typumwandlung.
"5" == 5 ist true (String wird zur Zahl).
0 == false ist true.
null == undefined ist true.

=== (strikte Gleichheit):
Vergleicht Werte UND Typ. Keine Umwandlung.
"5" === 5 ist false (String ungleich Zahl).
0 === false ist false.

Faustregel: Immer === verwenden.
```

---

```
A-015 | Theorie -> K-015
Ein Callback ist eine Funktion die einer anderen Funktion
als Argument übergeben und später aufgerufen wird.

setTimeout(function() { console.log('fertig') }, 1000)

Problem "Callback Hell": Verschachtelte Callbacks werden
schnell unlesbar:
getData(function(a) {
  getMore(a, function(b) {
    process(b, function(c) {
      // ... immer tiefer
    })
  })
})

Lösung: Promises und async/await statt verschachtelter Callbacks.
```

---

```
A-016 | Praxis -> K-016
.container {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 16px;
}

repeat(3, 1fr) = drei gleich breite Spalten.
gap = Abstand zwischen den Zellen.
Zeilen werden automatisch erzeugt.

Responsiv:
grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
Passt die Spaltenanzahl automatisch an die Breite an.
```

---

```
A-017 | Vertiefung -> K-017
REST (Representational State Transfer) ist ein Architekturstil für APIs.

Prinzipien:
1. Ressourcen haben URLs: /api/users/42
2. HTTP-Methoden für Aktionen: GET (lesen), POST (erstellen),
   PUT (aktualisieren), DELETE (löschen)
3. Zustandslos: Jede Anfrage enthält alle nötigen Informationen
4. JSON als Datenformat (meistens)
5. Einheitliche Schnittstelle: Gleiche Konventionen für alle Ressourcen

Beispiel: GET /api/users gibt alle User, GET /api/users/42 gibt User 42.
```

---

```
A-018 | Vertiefung -> K-018
CORS (Cross-Origin Resource Sharing) ist ein Sicherheitsmechanismus.

Problem: Browser blockiert Anfragen von einer Domain an eine andere.
Seite auf localhost:3000 darf nicht einfach api.example.com aufrufen.

Warum: Schutz vor bösartigen Seiten die im Namen des Users
API-Anfragen stellen (Cross-Site Request Forgery).

Lösung: Der Server muss CORS-Header setzen:
Access-Control-Allow-Origin: https://meine-seite.de
Access-Control-Allow-Methods: GET, POST, PUT, DELETE

Entwicklung: Oft Access-Control-Allow-Origin: * (alles erlauben).
Produktion: Nur die eigene Domain erlauben.
```

---

```
A-019 | Pruefung -> K-019
1. <header>  -- Kopfbereich der Seite oder eines Abschnitts
2. <nav>     -- Navigationsbereich (Menü, Links)
3. <main>    -- Hauptinhalt der Seite (nur einmal pro Seite)
4. <article> -- Eigenständiger Inhalt (Blogpost, Nachricht)
5. <footer>  -- Fußbereich der Seite oder eines Abschnitts

Weitere: <section>, <aside>, <figure>, <figcaption>, <time>.

Semantische Elemente verbessern Barrierefreiheit (Screenreader)
und SEO (Suchmaschinen verstehen die Seitenstruktur besser).
```

---

```
A-020 | Pruefung -> K-020
localStorage:
Dauerhaft gespeichert (auch nach Browser-Neustart).
Ca. 5-10 MB. Nur Strings. Gleiche Domain.
Für: Einstellungen, Theme-Wahl, Tokens.

sessionStorage:
Nur für die aktuelle Browser-Session (Tab schließen = weg).
Ca. 5 MB. Nur Strings. Gleiche Domain.
Für: Temporäre Formulardaten, Zwischenstände.

Cookies:
Werden bei JEDER HTTP-Anfrage zum Server mitgeschickt.
Max 4 KB. Ablaufdatum einstellbar.
Für: Session-IDs, Authentifizierung.
Achtung: Sicherheitsattribute setzen (HttpOnly, Secure, SameSite).
```
