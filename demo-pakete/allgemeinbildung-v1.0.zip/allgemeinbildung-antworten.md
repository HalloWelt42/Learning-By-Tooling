# Allgemeinbildung -- ANTWORTEN

---

```
A-001 | Grundlagen -> K-001
Unser Sonnensystem hat 8 Planeten:
1. Merkur
2. Venus
3. Erde
4. Mars
5. Jupiter
6. Saturn
7. Uranus
8. Neptun
Pluto wurde 2006 zum Zwergplaneten herabgestuft.
```

---

```
A-002 | Grundlagen -> K-002
Wetter beschreibt den kurzfristigen Zustand der Atmosphäre
an einem bestimmten Ort (Temperatur, Regen, Wind heute).

Klima ist der Durchschnitt des Wetters über einen langen
Zeitraum (mindestens 30 Jahre) in einer Region.

Beispiel: "Morgen regnet es" ist Wetter.
"In Deutschland sind die Sommer warm" ist Klima.
```

---

```
A-003 | Grundlagen -> K-003
Photosynthese ist der Prozess bei dem Pflanzen
Sonnenlicht, Wasser und CO2 in Zucker und Sauerstoff umwandeln.

Formel: 6 CO2 + 6 H2O + Licht -> C6H12O6 + 6 O2

Sie ist die Grundlage allen Lebens auf der Erde,
weil sie Sauerstoff produziert und Energie speichert.
```

---

```
A-004 | Theorie -> K-004
Die Einteilung geht auf die alten Ägypter zurück.
Sie teilten den Tag in 12 Stunden Helligkeit und
12 Stunden Dunkelheit.

Physikalisch: Die Erde dreht sich einmal in
23 Stunden und 56 Minuten um ihre Achse.
Die fehlenden 4 Minuten gleichen die Bewegung
um die Sonne aus.
```

---

```
A-005 | Theorie -> K-005
Einsteins Spezielle Relativitätstheorie (1905):
Nichts ist schneller als Licht (ca. 300.000 km/s).
Zeit vergeht langsamer je schneller man sich bewegt.
Energie und Masse sind austauschbar: E = mc2.

Allgemeine Relativitätstheorie (1915):
Schwerkraft ist keine Kraft sondern eine
Krümmung der Raumzeit durch Masse.
```

---

```
A-006 | Theorie -> K-006
Sonnenlicht besteht aus allen Farben (weißes Licht).
Wenn es in Wassertropfen eintritt wird es gebrochen
(wie durch ein Prisma) und in seine Farben aufgefächert.

Reihenfolge von außen nach innen:
Rot, Orange, Gelb, Grün, Blau, Indigo, Violett.

Man sieht ihn nur wenn die Sonne hinter einem
und der Regen vor einem ist.
```

---

```
A-007 | Praxis -> K-007
Formel: A = Pi x r2

Pi ist ungefähr 3,14159.
r ist der Radius (halber Durchmesser).

Beispiel: Kreis mit Radius 5 cm
A = 3,14159 x 25 = 78,54 cm2
```

---

```
A-008 | Praxis -> K-008
Formel: F = C x 1,8 + 32

Beispiele:
0 Grad C = 32 Grad F (Gefrierpunkt)
20 Grad C = 68 Grad F (Zimmertemperatur)
37 Grad C = 98,6 Grad F (Körpertemperatur)
100 Grad C = 212 Grad F (Siedepunkt)
```

---

```
A-009 | Verfahren -> K-009
Personalisiertes Verhältniswahlrecht mit Erst- und Zweitstimme.

Erststimme: Wählt einen Direktkandidaten im Wahlkreis.
Wer die meisten Stimmen hat gewinnt das Direktmandat.

Zweitstimme: Wählt eine Partei. Sie bestimmt die
Sitzverteilung im Bundestag (prozentual).

5-Prozent-Hürde: Parteien unter 5% der Zweitstimmen
kommen nicht in den Bundestag.
```

---

```
A-010 | Verfahren -> K-010
1. Gesetzentwurf wird eingebracht (Bundesregierung, Bundestag oder Bundesrat)
2. Erste Lesung im Bundestag (Vorstellung)
3. Ausschussberatung (Fachausschüsse prüfen Details)
4. Zweite Lesung (Diskussion und Änderungen)
5. Dritte Lesung (Schlussabstimmung)
6. Bundesrat stimmt zu (bei zustimmungspflichtigen Gesetzen)
7. Bundespräsident unterzeichnet
8. Veröffentlichung im Bundesgesetzblatt
```

---

```
A-011 | Grundlagen -> K-011
Drei Aggregatzustände:

1. Fest (Eis): unter 0 Grad Celsius
2. Flüssig (Wasser): 0 bis 100 Grad Celsius
3. Gasförmig (Dampf): über 100 Grad Celsius

Bei 0 Grad: Schmelz-/Gefrierpunkt
Bei 100 Grad: Siede-/Kondensationspunkt
(bei normalem Luftdruck auf Meereshöhe)
```

---

```
A-012 | Grundlagen -> K-012
Demokratie:
Macht geht vom Volk aus. Freie Wahlen, Meinungsfreiheit,
Gewaltenteilung (Legislative, Exekutive, Judikative),
Rechtsstaatlichkeit, Schutz von Minderheiten.

Diktatur:
Macht liegt bei einer Person oder kleinen Gruppe.
Keine freien Wahlen, eingeschränkte Grundrechte,
Zensur, keine unabhängige Justiz.
```

---

```
A-013 | Theorie -> K-013
DNA (Desoxyribonukleinsäure) ist ein Molekül das die
genetische Information aller Lebewesen speichert.

Aufbau: Doppelhelix aus zwei Strängen.
Die Sprossen bestehen aus Basenpaaren:
Adenin-Thymin und Guanin-Cytosin.

Funktion: Bauplan für Proteine, Vererbung von
Eigenschaften, Zellteilung.
```

---

```
A-014 | Theorie -> K-014
Die Erdachse ist um 23,5 Grad geneigt.
Dadurch treffen die Sonnenstrahlen je nach
Position auf der Umlaufbahn unterschiedlich steil auf.

Sommer: Eigene Hemisphäre ist zur Sonne geneigt.
Längere Tage, steilerer Sonneneinfallswinkel, wärmer.

Winter: Von der Sonne weg geneigt.
Kürzere Tage, flacherer Winkel, kälter.
```

---

```
A-015 | Vertiefung -> K-015
Die Industrielle Revolution begann ca. 1760 in England.

Kernmerkmale:
Übergang von Handarbeit zu Maschinenproduktion.
Dampfmaschine als Schlüsseltechnologie.
Urbanisierung (Land -> Stadt).
Entstehung der Arbeiterklasse.
Massenfertigung senkte Preise.

Bedeutung: Grundlage der modernen Wirtschaft,
Gesellschaft und Technologie.
```

---

```
A-016 | Vertiefung -> K-016
Der Treibhauseffekt ist ein natürlicher Prozess:
Sonnenstrahlung erwärmt die Erde.
Die Erde strahlt Wärme zurück.
Treibhausgase (CO2, Methan, Wasserdampf) in der
Atmosphäre halten einen Teil dieser Wärme fest.

Ohne ihn wäre die Erde ca. -18 Grad kalt.

Problem: Menschliche Aktivitäten erhöhen die
Treibhausgase. Mehr Wärme wird gespeichert.
Folge: Globale Erwärmung, Extremwetter, steigender Meeresspiegel.
```

---

```
A-017 | Pruefung -> K-017
1. Indien (ca. 1,44 Milliarden)
2. China (ca. 1,42 Milliarden)
3. USA (ca. 340 Millionen)
4. Indonesien (ca. 280 Millionen)
5. Pakistan (ca. 240 Millionen)

Stand: ca. 2024/2025.
Indien hat China als bevölkerungsreichstes Land überholt.
```

---

```
A-018 | Pruefung -> K-018
Die Berliner Mauer fiel am 9. November 1989.

Folgen:
Wiedervereinigung Deutschlands am 3. Oktober 1990.
Ende des Kalten Krieges.
Auflösung des Warschauer Pakts.
Zerfall der Sowjetunion (1991).
EU-Osterweiterung in den Folgejahren.
```

---

```
A-019 | Praxis -> K-019
Trick: 10% berechnen (Komma verschieben), dann multiplizieren.

Beispiel: 15% von 80 Euro
10% von 80 = 8 Euro
5% = die Hälfte davon = 4 Euro
15% = 8 + 4 = 12 Euro

Oder: 25% = ein Viertel, 50% = die Hälfte, 75% = drei Viertel.
```

---

```
A-020 | Allgemein -> K-020
Renaissance bedeutet "Wiedergeburt" (aus dem Französischen).

Epoche: ca. 1400 bis 1600, Beginn in Italien (Florenz).

Kernidee: Wiederentdeckung der antiken griechischen und
römischen Kultur, Kunst und Wissenschaft.

Wichtige Persönlichkeiten:
Leonardo da Vinci, Michelangelo, Galileo Galilei,
Gutenberg (Buchdruck), Kolumbus (Entdeckungsreisen).
```
