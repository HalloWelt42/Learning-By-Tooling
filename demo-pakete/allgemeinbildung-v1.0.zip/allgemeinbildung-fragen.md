# Allgemeinbildung -- FRAGEN
# 20 Karten zu Geschichte, Geografie, Naturwissenschaft, Kultur

---

```
K-001 | Grundlagen
Wie viele Planeten hat unser Sonnensystem und wie heißen sie?
```

---

```
K-002 | Grundlagen
Was ist der Unterschied zwischen Wetter und Klima?
```

---

```
K-003 | Grundlagen
Was versteht man unter Photosynthese?
```

---

```
K-004 | Theorie
Warum hat ein Tag 24 Stunden?
```

---

```
K-005 | Theorie
Was besagt die Relativitätstheorie in einfachen Worten?
```

---

```
K-006 | Theorie
Wie entsteht ein Regenbogen?
```

---

```
K-007 | Praxis
Wie berechnet man die Fläche eines Kreises?
```

---

```
K-008 | Praxis
Wie rechnet man Celsius in Fahrenheit um?
```

---

```
K-009 | Verfahren
Wie funktioniert das Wahlsystem in Deutschland (Bundestagswahl)?
```

---

```
K-010 | Verfahren
Wie wird ein Gesetz in Deutschland verabschiedet?
```

---

```
K-011 | Grundlagen
Welche drei Aggregatzustände hat Wasser und bei welchen Temperaturen wechselt es?
```

---

```
K-012 | Grundlagen
Was ist der Unterschied zwischen einer Demokratie und einer Diktatur?
```

---

```
K-013 | Theorie
Was ist DNA und welche Rolle spielt sie?
```

---

```
K-014 | Theorie
Warum gibt es Jahreszeiten?
```

---

```
K-015 | Vertiefung
Was war die Industrielle Revolution und warum war sie so bedeutsam?
```

---

```
K-016 | Vertiefung
Was ist der Treibhauseffekt und wie beeinflusst er das Klima?
```

---

```
K-017 | Pruefung
Nenne die fünf bevölkerungsreichsten Länder der Erde in der richtigen Reihenfolge.
```

---

```
K-018 | Pruefung
In welchem Jahr fiel die Berliner Mauer und was waren die Folgen?
```

---

```
K-019 | Praxis
Wie berechnet man Prozentsätze im Kopf? Gib ein Beispiel.
```

---

```
K-020 | Allgemein
Was bedeutet das Wort "Renaissance" und wann war diese Epoche?
```
