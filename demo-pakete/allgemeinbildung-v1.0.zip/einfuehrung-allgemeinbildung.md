# Allgemeinbildung -- Begleitmaterial

## Warum Allgemeinbildung?

Allgemeinbildung ist die Grundlage für informierte Entscheidungen im Alltag.
Sie hilft dir Zusammenhänge zu verstehen, Nachrichten einzuordnen und
an Gesprächen teilzunehmen.

Dieses Paket deckt vier Bereiche ab:
- Naturwissenschaft (Physik, Biologie, Chemie)
- Geschichte und Politik
- Geografie
- Mathematik im Alltag

## Naturwissenschaftliche Grundlagen

Die Erde ist einer von 8 Planeten im Sonnensystem. Sie dreht sich
einmal am Tag um ihre Achse und einmal im Jahr um die Sonne.

Die Neigung der Erdachse (23,5 Grad) erzeugt die Jahreszeiten.
Photosynthese in Pflanzen wandelt Sonnenlicht in Energie um und
produziert den Sauerstoff den wir atmen.

Wasser kommt in drei Zuständen vor: fest (Eis), flüssig und gasförmig (Dampf).
Die Übergänge passieren bei 0 und 100 Grad Celsius.

DNA ist der Bauplan des Lebens. Sie speichert genetische Informationen
in einer Doppelhelix-Struktur und wird bei der Zellteilung kopiert.

## Geschichte und Politik

Deutschland ist eine parlamentarische Demokratie mit Gewaltenteilung:
Legislative (Bundestag), Exekutive (Bundesregierung) und Judikative (Gerichte).

Die Berliner Mauer (1961-1989) teilte Deutschland in Ost und West.
Ihr Fall am 9. November 1989 führte zur Wiedervereinigung am 3. Oktober 1990.

Die Industrielle Revolution (ab ca. 1760) veränderte die Welt grundlegend:
Von Handarbeit zur Maschinenproduktion, von Land- zu Stadtleben.

## Mathematik im Alltag

Prozentrechnung: 10% berechnen (Komma verschieben) und daraus andere Werte ableiten.
Kreisfläche: Pi mal Radius zum Quadrat.
Temperaturumrechnung: Celsius mal 1,8 plus 32 ergibt Fahrenheit.

## Tipps zum Lernen

1. Fange mit den Grundlagen-Karten an (Kategorie Grundlagen)
2. Wechsle dann zu Theorie für tieferes Verständnis
3. Nutze die Praxis-Karten zum aktiven Anwenden
4. Prüfungs-Karten erst wenn du dich sicher fühlst
