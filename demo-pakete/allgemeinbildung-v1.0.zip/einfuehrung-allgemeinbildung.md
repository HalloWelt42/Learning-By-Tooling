# Allgemeinbildung -- Begleitmaterial

## Warum Allgemeinbildung wichtig ist

Allgemeinbildung ist kein Selbstzweck. Sie ist ein Werkzeug. Wer die Grundlagen von Naturwissenschaft, Geschichte, Politik und Mathematik versteht, kann Nachrichten einordnen, Argumente bewerten und fundierte Entscheidungen treffen. Allgemeinbildung schuetzt vor Manipulation, weil sie es ermoeglicht, Behauptungen zu ueberpruefen. Sie macht Gespraeche reicher, weil man Zusammenhaenge herstellen kann. Und sie hilft im Beruf, weil viele Probleme fachuebergreifendes Denken erfordern.

Dieses Begleitmaterial vertieft die Themen der Lernkarten in vier Bereichen: Naturwissenschaft, Geschichte und Politik, Geografie und Mathematik im Alltag. Lies es als Ergaenzung zu den Karten. Wenn eine Lernkarte eine kurze Antwort gibt, findest du hier den groesseren Zusammenhang.


## Unser Platz im Universum

### Das Sonnensystem

Die Erde ist einer von acht Planeten, die unsere Sonne umkreisen. Die Reihenfolge von innen nach aussen: Merkur, Venus, Erde, Mars, Jupiter, Saturn, Uranus, Neptun. Eine Eselsbruecke: "Mein Vater Erklaert Mir Jeden Sonntag Unseren Nachthimmel."

Die inneren vier Planeten (Merkur bis Mars) sind Gesteinsplaneten -- sie haben eine feste Oberflaeche. Die aeusseren vier (Jupiter bis Neptun) sind Gasriesen oder Eisriesen -- gewaltige Baelle aus Gas und Eis ohne festen Boden. Jupiter allein ist schwerer als alle anderen Planeten zusammen.

Pluto galt lange als neunter Planet. 2006 stufte die Internationale Astronomische Union ihn zum Zwergplaneten herab. Der Grund: Pluto hat seine Umlaufbahn nicht von anderen Objekten freigeraeumt, was eine der Bedingungen fuer den Planetenstatus ist.

### Warum es Tag und Nacht gibt

Die Erde dreht sich einmal in rund 24 Stunden um ihre eigene Achse. Genauer sind es 23 Stunden und 56 Minuten -- die fehlenden vier Minuten kommen dadurch zustande, dass sich die Erde gleichzeitig um die Sonne bewegt. Die Seite, die gerade zur Sonne zeigt, hat Tag. Die abgewandte Seite hat Nacht.

Die Einteilung des Tages in 24 Stunden geht auf die alten Aegypter zurueck. Sie teilten die helle und dunkle Phase in je 12 Abschnitte. Dieses System hat sich ueber Jahrtausende gehalten, obwohl es willkuerlich ist.

### Warum es Jahreszeiten gibt

Die Erdachse steht nicht senkrecht auf der Umlaufbahn, sondern ist um 23,5 Grad geneigt. Das ist der entscheidende Punkt. Wenn die Nordhalbkugel zur Sonne geneigt ist, treffen die Strahlen steiler auf, die Tage sind laenger und es wird waermer -- Sommer. Ein halbes Jahr spaeter ist die Nordhalbkugel von der Sonne weggeneigt, die Strahlen fallen flacher ein, die Tage sind kuerzer -- Winter.

Wichtig: Die Jahreszeiten entstehen nicht durch den Abstand zur Sonne. Tatsaechlich ist die Erde im Januar (Nordhalbkugel-Winter) sogar etwas naeher an der Sonne als im Juli. Der Einfallswinkel macht den Unterschied, nicht die Entfernung.


## Naturwissenschaftliche Grundlagen

### Photosynthese -- wie Pflanzen Energie erzeugen

Pflanzen sind die Grundlage fast allen Lebens auf der Erde. Sie wandeln Sonnenlicht, Wasser und Kohlendioxid in Zucker (Glukose) und Sauerstoff um. Dieser Vorgang heisst Photosynthese.

Die vereinfachte Gleichung: 6 CO2 + 6 H2O + Lichtenergie ergibt C6H12O6 + 6 O2.

In Worten: Sechs Molekuele Kohlendioxid plus sechs Molekuele Wasser plus Licht ergeben ein Molekuel Traubenzucker und sechs Molekuele Sauerstoff.

Der Sauerstoff, den wir atmen, ist ein Nebenprodukt der Photosynthese. Ohne Pflanzen gaebe es keinen freien Sauerstoff in der Atmosphaere und damit kein tierisches Leben, wie wir es kennen. Gleichzeitig binden Pflanzen CO2 -- ein Treibhausgas. Das macht sie zu einem zentralen Element im Klimasystem.

### Aggregatzustaende -- warum Wasser Eis wird

Jeder Stoff kann in verschiedenen Zustaenden vorkommen: fest, fluessig und gasfoermig. Bei Wasser kennen wir alle drei aus dem Alltag:

- Unter 0 Grad Celsius: Eis (fest)
- Zwischen 0 und 100 Grad Celsius: Wasser (fluessig)
- Ueber 100 Grad Celsius: Dampf (gasfoermig)

Diese Temperaturen gelten bei normalem Luftdruck auf Meerehoehe. Auf einem hohen Berg, wo der Luftdruck niedriger ist, kocht Wasser schon bei weniger als 100 Grad. Im Druckkochtopf, wo der Druck hoeher ist, erst bei ueber 100 Grad.

Der Uebergang von fest zu fluessig heisst Schmelzen. Von fluessig zu fest: Erstarren oder Gefrieren. Von fluessig zu gasfoermig: Verdampfen. Von gasfoermig zu fluessig: Kondensieren. Es gibt auch den direkten Uebergang von fest zu gasfoermig (Sublimation) -- das passiert zum Beispiel, wenn Eis bei trockener Kaelte direkt verdampft, ohne vorher zu schmelzen.

### DNA -- der Bauplan des Lebens

DNA steht fuer Desoxyribonukleinsaeure. Sie ist ein langes Molekuel in Form einer Doppelhelix -- zwei Straenge, die sich spiralfoermig umeinander winden. Verbunden werden die Straenge durch Basenpaare: Adenin paart sich immer mit Thymin, Guanin immer mit Cytosin. Die Reihenfolge dieser Basen bildet den genetischen Code.

Die DNA enthaelt die Bauanleitung fuer Proteine. Proteine wiederum sind die Arbeitstiere der Zelle: Sie transportieren Stoffe, beschleunigen chemische Reaktionen, bilden Strukturen und steuern Prozesse. Die DNA wird bei jeder Zellteilung kopiert, damit die Tochterzellen dieselbe Information erhalten.

Wenn bei der Kopie Fehler passieren, entstehen Mutationen. Die meisten sind harmlos oder schaedlich. Aber gelegentlich bringt eine Mutation einen Vorteil -- das ist der Rohstoff der Evolution.

### Licht und Farben -- warum der Regenbogen bunt ist

Weisses Sonnenlicht ist kein einzelnes Licht, sondern eine Mischung aller sichtbaren Farben. Wenn ein Lichtstrahl in einen Wassertropfen eintritt, wird er gebrochen -- aehnlich wie bei einem Glasprisma. Verschiedene Farben werden unterschiedlich stark gebrochen: Rotes Licht wird weniger abgelenkt als violettes. Dadurch faechert sich das weisse Licht in seine Bestandteile auf.

Die Farbreihenfolge eines Regenbogens von aussen nach innen: Rot, Orange, Gelb, Gruen, Blau, Indigo, Violett. Einen Regenbogen siehst du nur, wenn die Sonne hinter dir steht und der Regen vor dir faellt.

### Einsteins Relativitaetstheorie -- einfach erklaert

Albert Einstein veroeffentlichte 1905 die Spezielle Relativitaetstheorie. Ihre beiden Kernaussagen: Erstens, die Lichtgeschwindigkeit (rund 300.000 Kilometer pro Sekunde) ist die absolute Hoechstgeschwindigkeit im Universum. Nichts kann schneller sein. Zweitens, Zeit ist nicht absolut. Sie vergeht langsamer, je schneller sich ein Objekt bewegt. Fuer jemanden, der mit annaehernd Lichtgeschwindigkeit reist, vergeht die Zeit langsamer als fuer jemanden, der stillsteht. Das klingt absurd, ist aber experimentell bestaetigt.

Die beruehmte Formel E = mc2 besagt: Energie und Masse sind austauschbar. Eine kleine Menge Masse enthaelt eine enorme Menge Energie. Das erklaert, warum Kernspaltung und Kernfusion so gewaltige Energiemengen freisetzen.

1915 folgte die Allgemeine Relativitaetstheorie. Sie beschreibt Schwerkraft nicht als Kraft, sondern als Kruemmung der Raumzeit. Grosse Massen biegen den Raum, und Objekte folgen dieser Kruemmung. Die Erde faellt nicht auf die Sonne zu, weil eine Kraft sie zieht, sondern weil die Sonne den Raum um sich herum kruemmt und die Erde dieser Kruemmung folgt.


## Geschichte und Politik

### Das politische System Deutschlands

Deutschland ist eine parlamentarische Demokratie und ein foederaler Bundesstaat. Das bedeutet: Die Macht geht vom Volk aus (Demokratie), die Regierung ist dem Parlament verantwortlich (parlamentarisch), und die 16 Bundeslaender haben eigene Zustaendigkeiten (foederal).

Die Gewaltenteilung ist ein zentrales Prinzip:

- Legislative (gesetzgebende Gewalt): Der Bundestag beschliesst Gesetze. Der Bundesrat vertritt die Laender und muss bei bestimmten Gesetzen zustimmen.
- Exekutive (ausfuehrende Gewalt): Die Bundesregierung unter dem Bundeskanzler setzt die Gesetze um.
- Judikative (rechtsprechende Gewalt): Unabhaengige Gerichte ueberpruefen, ob Gesetze eingehalten werden. Das Bundesverfassungsgericht kann Gesetze fuer verfassungswidrig erklaeren.

### Wie Wahlen funktionieren

Bei der Bundestagswahl hat jeder Waehler zwei Stimmen. Die Erststimme waehlt einen Direktkandidaten im Wahlkreis -- wer die meisten Stimmen hat, zieht direkt in den Bundestag ein. Die Zweitstimme waehlt eine Partei. Sie bestimmt die Sitzverteilung im Bundestag prozentual. Die Zweitstimme ist daher die entscheidendere.

Es gibt eine 5-Prozent-Huerde: Parteien, die weniger als 5 Prozent der Zweitstimmen erhalten, kommen nicht in den Bundestag. Diese Huerde soll eine Zersplitterung des Parlaments in zu viele kleine Parteien verhindern.

### Wie ein Gesetz entsteht

Der Weg eines Gesetzes ist mehrstufig und bewusst so gestaltet, dass Entscheidungen gruendlich geprueft werden:

1. Ein Gesetzentwurf wird eingebracht -- durch die Bundesregierung, den Bundestag oder den Bundesrat.
2. Erste Lesung im Bundestag: Der Entwurf wird vorgestellt und diskutiert.
3. Ausschussberatung: Fachausschuesse pruefen den Entwurf im Detail und koennen Aenderungen vorschlagen.
4. Zweite Lesung: Diskussion und Abstimmung ueber Aenderungsantraege.
5. Dritte Lesung: Schlussabstimmung.
6. Bei zustimmungspflichtigen Gesetzen muss der Bundesrat zustimmen.
7. Der Bundespraesi dent unterzeichnet das Gesetz.
8. Veroeffentlichung im Bundesgesetzblatt -- ab dann gilt es.

### Demokratie und Diktatur

Eine Demokratie zeichnet sich aus durch freie Wahlen, Meinungsfreiheit, Pressefreiheit, Gewaltenteilung, Rechtsstaatlichkeit und den Schutz von Minderheiten. Die Macht geht vom Volk aus und wird durch gewaehlte Vertreter ausgeuebt.

In einer Diktatur liegt die Macht bei einer Person oder einer kleinen Gruppe. Es gibt keine freien Wahlen, Grundrechte sind eingeschraenkt, die Medien werden zensiert und die Justiz ist nicht unabhaengig. Diktaturen koennen verschiedene Formen annehmen: Militaerdiktatur, Einparteienherrschaft oder personalisierte Autokratie.

### Die Berliner Mauer und die Wiedervereinigung

Nach dem Zweiten Weltkrieg wurde Deutschland in vier Besatzungszonen geteilt. Aus den westlichen Zonen entstand 1949 die Bundesrepublik Deutschland (BRD), aus der sowjetischen Zone die Deutsche Demokratische Republik (DDR). Berlin, mitten in der DDR gelegen, wurde ebenfalls geteilt.

Am 13. August 1961 begann die DDR mit dem Bau der Berliner Mauer, um die Massenflucht in den Westen zu stoppen. Ueber 28 Jahre teilte die Mauer die Stadt und das Land. Mindestens 140 Menschen starben beim Versuch, die Mauer zu ueberwinden.

Am 9. November 1989 fiel die Mauer. Die Folgen waren enorm: Am 3. Oktober 1990 wurde Deutschland wiedervereinigt. Der Kalte Krieg ging zu Ende. Der Warschauer Pakt loeste sich auf. Die Sowjetunion zerfiel 1991. In den Folgejahren traten viele osteuropaeische Laender der EU bei.

### Die Industrielle Revolution

Ab etwa 1760 veraenderte die Industrielle Revolution in England die Welt grundlegend. Die Dampfmaschine war die Schluesseltechnologie. Vorher wurde fast alles von Hand gefertigt. Nun uebernahmen Maschinen die Arbeit in Fabriken.

Die Folgen waren weitreichend: Millionen Menschen zogen vom Land in die Staedte (Urbanisierung). Eine neue Gesellschaftsschicht entstand -- die Arbeiterklasse, die unter oft harten Bedingungen in Fabriken arbeitete. Die Massenproduktion senkte die Preise fuer viele Gueter. Gleichzeitig verschaerften sich soziale Ungleichheiten, was spaeter zu Arbeiterbewegungen, Gewerkschaften und Sozialgesetzgebung fuehrte.

Die Industrielle Revolution ist die Grundlage der modernen Wirtschaft, Technologie und Gesellschaft. Ohne sie gaebe es keine Eisenbahn, keine Elektrizitaet, keine modernen Staedte.

### Die Renaissance

Das Wort "Renaissance" kommt aus dem Franzoesischen und bedeutet "Wiedergeburt". Die Epoche dauerte von etwa 1400 bis 1600 und begann in Italien, besonders in Florenz. Ihr Kern war die Wiederentdeckung der antiken griechischen und roemischen Kultur, Kunst und Wissenschaft.

Wichtige Persoenlichkeiten: Leonardo da Vinci (Maler, Erfinder, Universalgenie), Michelangelo (Bildhauer, Maler der Sixtinischen Kapelle), Galileo Galilei (Astronom, bestaetigt das heliozentrische Weltbild), Johannes Gutenberg (erfindet den Buchdruck mit beweglichen Lettern) und Christoph Kolumbus (erreicht 1492 Amerika).

Der Buchdruck war besonders folgenreich: Zum ersten Mal konnten Wissen und Ideen schnell und in grosser Zahl verbreitet werden. Das verstaerkte die wissenschaftliche Revolution und die Reformation.


## Der Treibhauseffekt und das Klima

### Wetter und Klima -- ein wichtiger Unterschied

Wetter beschreibt den kurzfristigen Zustand der Atmosphaere an einem bestimmten Ort: Ist es gerade warm oder kalt, regnet es, weht Wind? Wetter aendert sich von Tag zu Tag.

Klima ist der Durchschnitt des Wetters ueber einen langen Zeitraum -- mindestens 30 Jahre. "In Deutschland sind die Sommer warm" ist eine Aussage ueber das Klima. "Morgen regnet es" ist eine Aussage ueber das Wetter.

### Wie der Treibhauseffekt funktioniert

Der Treibhauseffekt ist zunaechst ein natuerlicher und lebenswichtiger Vorgang. Die Sonne strahlt Energie auf die Erde. Die Erde erwaermt sich und strahlt Waerme zurueck ins All. Aber bestimmte Gase in der Atmosphaere -- Kohlendioxid (CO2), Methan, Wasserdampf -- fangen einen Teil dieser Waerme ab und reflektieren sie zurueck zur Erde.

Ohne diesen natuerlichen Treibhauseffekt waere die durchschnittliche Temperatur auf der Erde etwa minus 18 Grad Celsius -- viel zu kalt fuer Leben wie wir es kennen. Der natuerliche Treibhauseffekt heizt die Erde auf ertraegliche plus 15 Grad im Durchschnitt.

Das Problem: Menschliche Aktivitaeten -- Verbrennung fossiler Brennstoffe, Abholzung, Landwirtschaft -- erhoehen die Konzentration von Treibhausgasen in der Atmosphaere. Mehr Treibhausgase speichern mehr Waerme. Die Folge ist die globale Erwaermung: steigende Durchschnittstemperaturen, haeufigere Extremwetterereignisse, schmelzende Gletscher und Polkappen, steigender Meeresspiegel.


## Geografie

### Die bevoelkerungsreichsten Laender

Etwa 8 Milliarden Menschen leben auf der Erde. Die fuenf bevoelkerungsreichsten Laender (Stand ca. 2024/2025):

1. Indien -- rund 1,44 Milliarden
2. China -- rund 1,42 Milliarden
3. USA -- rund 340 Millionen
4. Indonesien -- rund 280 Millionen
5. Pakistan -- rund 240 Millionen

Indien hat China im Jahr 2023 als bevoelkerungsreichstes Land ueberholt. Chinas Bevoelkerung schrumpft inzwischen, waehrend Indiens noch waechst. Diese demografischen Verschiebungen haben grosse wirtschaftliche und politische Auswirkungen.


## Mathematik im Alltag

### Prozentrechnung im Kopf

Prozentrechnung begegnet dir staendig: Rabatte, Steuern, Zinsen, Statistiken. Mit einem einfachen Trick kannst du viele Prozentwerte im Kopf berechnen:

Schritt 1: Berechne 10 Prozent, indem du das Komma um eine Stelle nach links verschiebst. 10 Prozent von 80 Euro sind 8 Euro. 10 Prozent von 250 Euro sind 25 Euro.

Schritt 2: Leite daraus andere Werte ab. 5 Prozent ist die Haelfte von 10 Prozent. 20 Prozent ist das Doppelte. 1 Prozent bekommst du, indem du 10 Prozent nochmal durch 10 teilst.

Beispiel: 15 Prozent von 80 Euro. 10 Prozent = 8 Euro. 5 Prozent = 4 Euro. 15 Prozent = 8 + 4 = 12 Euro.

Weitere Abkuerzungen: 25 Prozent = ein Viertel, 50 Prozent = die Haelfte, 75 Prozent = drei Viertel. Bei 80 Euro waeren 25 Prozent also 20 Euro.

### Kreisflaeche berechnen

Die Formel fuer die Flaeche eines Kreises: A = Pi mal r zum Quadrat (A = Pi * r * r).

Pi ist eine mathematische Konstante mit dem Wert 3,14159... -- fuer die meisten Zwecke reicht 3,14. Der Radius (r) ist der Abstand vom Mittelpunkt zum Rand des Kreises -- also der halbe Durchmesser.

Beispiel: Ein runder Tisch mit 1,20 Meter Durchmesser. Der Radius ist 0,60 Meter. Die Flaeche: 3,14 * 0,6 * 0,6 = 3,14 * 0,36 = 1,13 Quadratmeter.

### Temperaturumrechnung

Die Formel: Fahrenheit = Celsius mal 1,8 plus 32. Oder umgekehrt: Celsius = (Fahrenheit minus 32) geteilt durch 1,8.

Einige Ankerwerte zum Merken:

- 0 Grad Celsius = 32 Grad Fahrenheit (Gefrierpunkt von Wasser)
- 20 Grad Celsius = 68 Grad Fahrenheit (angenehme Raumtemperatur)
- 37 Grad Celsius = 98,6 Grad Fahrenheit (normale Koerpertemperatur)
- 100 Grad Celsius = 212 Grad Fahrenheit (Siedepunkt von Wasser)

Eine grobe Faustregel fuer den Alltag: Celsius verdoppeln und 30 addieren ergibt einen ungefaehren Fahrenheit-Wert. 20 Grad Celsius: 20 * 2 + 30 = 70 Fahrenheit (tatsaechlich 68, also recht nah dran).


## Tipps zum Lernen mit den Karten

Dieses Lernpaket ist in Schwierigkeitsgrade aufgeteilt. Ein sinnvoller Lernpfad:

1. Beginne mit den Grundlagen-Karten (K-001 bis K-003, K-011, K-012). Sie behandeln die Basiskonzepte: Sonnensystem, Wetter vs. Klima, Photosynthese, Aggregatzustaende, Demokratie vs. Diktatur.

2. Gehe dann zur Theorie (K-004 bis K-006, K-013, K-014). Hier wird es anspruchsvoller: Tag-Nacht-Rhythmus, Relativitaetstheorie, Regenbogen, DNA, Jahreszeiten.

3. Die Praxis-Karten (K-007, K-008, K-019) testen angewandtes Wissen: Kreisflaeche, Temperaturumrechnung, Prozentrechnung im Kopf.

4. Vertiefung (K-015, K-016) und Verfahren (K-009, K-010) fuehren in komplexere Themen: Industrielle Revolution, Treibhauseffekt, Wahlsystem, Gesetzgebung.

5. Die Pruefungs-Karten (K-017, K-018) sind die haerteste Stufe. Versuche sie erst, wenn du dich bei den anderen Kategorien sicher fuehlst.

Nutze die Wiederholungsfunktion konsequent. Wissen, das in regelmaessigen Abstaenden abgerufen wird, bleibt deutlich besser im Gedaechtnis als Wissen, das einmal intensiv gelernt und dann vergessen wird.
